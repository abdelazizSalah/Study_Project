#!/usr/bin/env python3
"""
task1c.py — Task 1(c): Host-pair counts & inter-arrival stats (multi-dataset)
------------------------------------------------------------------------------

Usage examples
python3 task1c.py \
  --pcap 'characterization_modbus_6RTU_with_operate (1).pcap' \
  --labels 'characterization_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'CnC_uploading_exe_modbus_6RTU_with_operate.pcap' \
  --labels 'CnC_uploading_exe_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'exploit_ms08_netapi_modbus_6RTU_with_operate.pcap' \
  --labels 'exploit_ms08_netapi_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'Modbus_polling_only_6RTU(2).pcap' \
  --labels 'Modbus_polling_only_6RTU_labeled.csv' \
  --pcap 'moving_two_files_modbus_6RTU.pcap' \
  --labels 'moving_two_files_modbus_6RTU_labeled.csv' \
  --pcap 'run1_12rtu_fixed.pcap' \
  --labels 'run1_12rtu_labeled.csv' \
  --pcap 'run11.pcap' \
  --labels 'run11_labeled.csv' \
  --pcap 'run1_3rtu_2s.pcap' \
  --labels 'run1_3rtu_2s_labeled (1).csv' \
  --pcap 'run1_6rtu(1).pcap' \
  --labels 'run1_6rtu_labeled.csv' \
  --pcap 'run8.pcap' \
  --labels 'run8_labeled.csv' \
  --pcap 'send_a_fake_command_modbus_6RTU_with_operate.pcap' \
  --labels 'send_a_fake_command_modbus_6RTU_with_operate_labeled (1).csv' \
  --outdir task1c_rez --outfile-base ALL --per-pair-csv --verbose
"""

import argparse
import os
import numpy as np
import pandas as pd
import pyshark

#helpers

INFRA_LAYERS = {
    "ETH", "ETHERNET", "LLC", "STP", "VLAN", "IP", "IPV6",
    "TCP", "UDP", "ICMP", "ICMPV6", "ARP", "NBNS", "SSDP", "MDNS",
    "DATA", "UNKNOWN"
}

def normalize_app(app: str) -> str:
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def is_application_layer(app: str) -> bool:
    return bool(app) and app.upper() not in INFRA_LAYERS

def load_labels(labels_path: str | None, verbose: bool=False) -> set[int]:
    """Return set of malicious frame numbers (or empty set if no labels)."""
    if not labels_path:
        if verbose:
            print("No labels provided → treating all packets as NORMAL (no attacks).")
        return set()
    df = pd.read_csv(labels_path, engine="python", sep=None, header=None)
    if df.shape[1] != 2:
        raise SystemExit("ERROR: labels CSV must have 2 columns: frame_number;label")
    df.columns = ["frame_number", "label"]
    mal = set(df.loc[df["label"] == 1, "frame_number"].astype(int).tolist())
    if verbose:
        print(f"Loaded labels: {len(df)} rows, {len(mal)} malicious frames")
    return mal

#packet collection

def collect_packets(pcap_path: str, mal_frames: set[int], verbose: bool=False) -> pd.DataFrame:
    """
    Returns DataFrame with columns:
      frame, ts, src, dst, app, trans, length, is_mal
    """
    cap = pyshark.FileCapture(pcap_path, keep_packets=False)
    rows = []
    total = 0
    for pkt in cap:
        total += 1
        if verbose and total % 1_000_000 == 0:
            print(f"[progress] {os.path.basename(pcap_path)}: processed {total:,} packets…")

        # frame number
        try:
            frame = int(getattr(pkt, "number", total))
        except Exception:
            frame = total
        is_mal = frame in mal_frames

        # timestamp
        ts = None
        try:
            ts = float(pkt.sniff_time.timestamp())
        except Exception:
            try:
                ts = float(pkt.frame_info.time_epoch)
            except Exception:
                ts = None

        # endpoints
        src = dst = None
        if hasattr(pkt, "ip"):
            src, dst = pkt.ip.src, pkt.ip.dst
        elif hasattr(pkt, "ipv6"):
            src, dst = pkt.ipv6.src, pkt.ipv6.dst

        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        trans = getattr(pkt, "transport_layer", None) or "UNKNOWN"
        try:
            length = int(pkt.length)
        except Exception:
            length = None

        rows.append((frame, ts, src, dst, app, trans, length, is_mal))

    cap.close()
    df = pd.DataFrame(rows, columns=["frame","ts","src","dst","app","trans","length","is_mal"])
    if verbose:
        print(f"[done] {os.path.basename(pcap_path)}: collected packets = {len(df):,}")
    return df

# core computations

def compute_pairs_overview(df_app: pd.DataFrame) -> tuple[int, int]:
    """
    Count total unordered IP pairs (with any app-data packets),
    and how many of those pairs have >=1 malicious packet.
    """
    df = df_app.dropna(subset=["src","dst"]).copy()
    if df.empty:
        return 0, 0
    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    total_pairs = df["pair"].nunique()
    pair_mal = df.groupby("pair")["is_mal"].any().sum()
    return int(total_pairs), int(pair_mal)

def compute_interarrival_by_pair_app(df_app: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """
    Build inter-arrival deltas per (unordered pair, app) for:
      - NORMAL_strict: consecutive normal packets
      - MALICIOUS_strict: consecutive malicious packets
    Also aggregate per app (weighted by deltas count).
    """
    df = df_app.dropna(subset=["ts","src","dst"]).copy()
    if df.empty:
        empty_pair = pd.DataFrame(columns=["src","dst","app","subset","count","mean","std","median"])
        empty_app  = pd.DataFrame(columns=["app","subset","count","mean","std","median"])
        return {
            "pair_normal_strict": empty_pair,
            "pair_malicious_strict": empty_pair,
            "app_normal_strict": empty_app,
            "app_malicious_strict": empty_app,
        }

    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    df = df.sort_values(["pair","app","ts"])
    groups = df.groupby(["pair","app"], sort=False)

    rows_normal, rows_mal = [], []

    for (pair, app), g in groups:
        ts  = g["ts"].to_numpy(dtype=float)
        is_m = g["is_mal"].to_numpy()
        is_n = ~is_m
        if ts.size < 2:
            continue

        # NORMAL_strict: both packets are normal
        norm_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_n[i] and is_n[i+1]]
        if norm_d:
            norm_d = np.array(norm_d, dtype=float)
            rows_normal.append((
                pair[0], pair[1], app, "NORMAL_strict", len(norm_d),
                float(np.mean(norm_d)),
                float(np.std(norm_d, ddof=1)) if len(norm_d) > 1 else 0.0,
                float(np.median(norm_d)),
            ))

        # MALICIOUS_strict: both packets are malicious
        mal_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_m[i] and is_m[i+1]]
        if mal_d:
            mal_d = np.array(mal_d, dtype=float)
            rows_mal.append((
                pair[0], pair[1], app, "MALICIOUS_strict", len(mal_d),
                float(np.mean(mal_d)),
                float(np.std(mal_d, ddof=1)) if len(mal_d) > 1 else 0.0,
                float(np.median(mal_d)),
            ))

    cols = ["src","dst","app","subset","count","mean","std","median"]
    df_pair_normal = pd.DataFrame(rows_normal, columns=cols)
    df_pair_mal    = pd.DataFrame(rows_mal,    columns=cols)

    def agg_per_app(df_pair: pd.DataFrame, subset_name: str) -> pd.DataFrame:
        if df_pair.empty:
            return pd.DataFrame(columns=["app","subset","count","mean","std","median"])
        g = df_pair.groupby("app", as_index=False)
        rows = []
        for app, subdf in g:
            c_total = subdf["count"].sum()
            m_pool = (subdf["count"] * subdf["mean"]).sum() / c_total
            # pooled std approx
            if c_total > 1:
                var_terms = ((subdf["count"] - 1) * (subdf["std"]**2)).fillna(0.0) \
                            + subdf["count"] * ((subdf["mean"] - m_pool)**2)
                var_pool = var_terms.sum() / (c_total - 1)
                s_pool = float(np.sqrt(max(var_pool, 0.0)))
            else:
                s_pool = 0.0
            med_pool = float((subdf["count"] * subdf["median"]).sum() / c_total)
            rows.append((app, subset_name, int(c_total), float(m_pool), float(s_pool), float(med_pool)))
        return pd.DataFrame(rows, columns=["app","subset","count","mean","std","median"])

    app_normal = agg_per_app(df_pair_normal, "NORMAL_strict")
    app_mal    = agg_per_app(df_pair_mal,    "MALICIOUS_strict")

    return {
        "pair_normal_strict": df_pair_normal,
        "pair_malicious_strict": df_pair_mal,
        "app_normal_strict": app_normal,
        "app_malicious_strict": app_mal,
    }

# saving & printing

def save_structured_csv(pair_counts: dict, interstats: dict, out_path: str) -> str:
    """
    Write a single structured CSV with sections:
      - pairs_overview
      - interarrival_pair_normal_strict
      - interarrival_pair_malicious_strict
      - interarrival_app_normal_strict
      - interarrival_app_malicious_strict
    """
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    rows = []

    # pairs overview
    rows.append({"section":"pairs_overview","metric":"total_pairs","value":pair_counts["total_pairs"]})
    rows.append({"section":"pairs_overview","metric":"pairs_with_attacks","value":pair_counts["pairs_with_attacks"]})
    rows.append({"section":"pairs_overview","metric":"pairs_without_attacks","value":pair_counts["total_pairs"] - pair_counts["pairs_with_attacks"]})

    # pair-level inter-arrival
    for section_key in ["pair_normal_strict", "pair_malicious_strict"]:
        dfp = interstats[section_key]
        if not dfp.empty:
            for _, r in dfp.iterrows():
                rows.append({
                    "section": section_key,
                    "app_protocol": r["app"],
                    "src_ip": r["src"],
                    "dst_ip": r["dst"],
                    "subset": r["subset"],
                    "count": int(r["count"]),
                    "mean": float(r["mean"]),
                    "std": float(r["std"]),
                    "median": float(r["median"]),
                })

    # app-level aggregates
    for section_key in ["app_normal_strict", "app_malicious_strict"]:
        dfa = interstats[section_key]
        if not dfa.empty:
            for _, r in dfa.iterrows():
                rows.append({
                    "section": section_key,
                    "app_protocol": r["app"],
                    "src_ip": "",
                    "dst_ip": "",
                    "subset": r["subset"],
                    "count": int(r["count"]),
                    "mean": float(r["mean"]) if pd.notna(r["mean"]) else "",
                    "std": float(r["std"]) if pd.notna(r["std"]) else "",
                    "median": float(r["median"]) if pd.notna(r["median"]) else "",
                })

    pd.DataFrame(rows, columns=[
        "section","metric","value","app_protocol","src_ip","dst_ip","subset","count","mean","std","median"
    ]).to_csv(out_path, index=False)
    return out_path

def save_pretty_csv(pair_counts: dict, interstats: dict, out_path: str) -> str:
    """Pretty CSV mirroring console lines (one text line per row)."""
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    lines = []
    lines.append("=== Task 1(c) Summary ===")
    lines.append("")
    lines.append(f"Total unordered host pairs (with app data): {pair_counts['total_pairs']}")
    lines.append(f"Pairs with attacks: {pair_counts['pairs_with_attacks']}")
    lines.append(f"Pairs without attacks: {pair_counts['total_pairs'] - pair_counts['pairs_with_attacks']}")
    lines.append("")

    # NORMAL_strict pairs
    lines.append("Inter-arrival (seconds) — same unordered host pair AND same app — WITHOUT attacks (NORMAL_strict):")
    dfpn = interstats["pair_normal_strict"]
    if dfpn.empty:
        lines.append("  (none)")
    else:
        for _, r in dfpn.sort_values(["app","src","dst"]).iterrows():
            lines.append(
                f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                f"mean={float(r['mean']):.6f}s, std={(0.0 if pd.isna(r['std']) else float(r['std'])):.6f}s, "
                f"median={float(r['median']):.6f}s"
            )
    lines.append("")

    # MALICIOUS_strict pairs
    lines.append("Inter-arrival (seconds) — same unordered host pair AND same app — WITH attacks (MALICIOUS_strict):")
    dfpm = interstats["pair_malicious_strict"]
    if dfpm.empty:
        lines.append("  (none)")
    else:
        for _, r in dfpm.sort_values(["app","src","dst"]).iterrows():
            lines.append(
                f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                f"mean={float(r['mean']):.6f}s, std={(0.0 if pd.isna(r['std']) else float(r['std'])):.6f}s, "
                f"median={float(r['median']):.6f}s"
            )
    lines.append("")

    # app aggregates
    dfa_n = interstats["app_normal_strict"]
    dfa_m = interstats["app_malicious_strict"]

    lines.append("Aggregated per application — WITHOUT attacks (NORMAL_strict):")
    if dfa_n.empty:
        lines.append("  (none)")
    else:
        for _, r in dfa_n.sort_values(["app"]).iterrows():
            lines.append(
                f"  {r['app']}: deltas={int(r['count'])}, mean={float(r['mean']):.6f}s, "
                f"std={(0.0 if pd.isna(r['std']) else float(r['std'])):.6f}s, median={float(r['median']):.6f}s"
            )
    lines.append("")

    lines.append("Aggregated per application — WITH attacks (MALICIOUS_strict):")
    if dfa_m.empty:
        lines.append("  (none)")
    else:
        for _, r in dfa_m.sort_values(["app"]).iterrows():
            lines.append(
                f"  {r['app']}: deltas={int(r['count'])}, mean={float(r['mean']):.6f}s, "
                f"std={(0.0 if pd.isna(r['std']) else float(r['std'])):.6f}s, median={float(r['median']):.6f}s"
            )
    lines.append("")

    pd.DataFrame({"text": lines}).to_csv(out_path, index=False)
    return out_path

def print_summary(pair_counts: dict, interstats: dict, header: str | None = None) -> None:
    if header:
        print(header)
    print("\n=== Task 1(c) Summary ===\n")
    print(f"Total unordered host pairs (with app data): {pair_counts['total_pairs']}")
    print(f"Pairs with attacks: {pair_counts['pairs_with_attacks']}")
    print(f"Pairs without attacks: {pair_counts['total_pairs'] - pair_counts['pairs_with_attacks']}\n")

    def print_pairs_block(df_pair: pd.DataFrame, title: str):
        print(title)
        if df_pair.empty:
            print("  (none)\n")
            return
        for _, r in df_pair.sort_values(["app","src","dst"]).iterrows():
            print(f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                  f"mean={float(r['mean']):.6f}s, std={(0.0 if pd.isna(r['std']) else float(r['std'])):.6f}s, "
                  f"median={float(r['median']):.6f}s")
        print("")

    print_pairs_block(interstats["pair_normal_strict"],
        "Inter-arrival (seconds) — same unordered host pair AND same app — WITHOUT attacks (NORMAL_strict):")
    print_pairs_block(interstats["pair_malicious_strict"],
        "Inter-arrival (seconds) — same unordered host pair AND same app — WITH attacks (MALICIOUS_strict):")

    def print_app_block(dfa: pd.DataFrame, title: str):
        print(title)
        if dfa.empty:
            print("  (none)\n")
            return
        for _, r in dfa.sort_values(["app"]).iterrows():
            print(f"  {r['app']}: deltas={int(r['count'])}, mean={float(r['mean']):.6f}s, "
                  f"std={(0.0 if pd.isna(r['std']) else float(r['std'])):.6f}s, median={float(r['median']):.6f}s")
        print("")

    print_app_block(interstats["app_normal_strict"],   "Aggregated per application — WITHOUT attacks (NORMAL_strict):")
    print_app_block(interstats["app_malicious_strict"],"Aggregated per application — WITH attacks (MALICIOUS_strict):")



def main():
    ap = argparse.ArgumentParser(description="Task 1(c): Pair counts & inter-arrival (multi-dataset)")
    ap.add_argument("--pcap", action="append", required=True,
                    help="Input .pcap (repeatable). Order aligns with --labels if provided.")
    ap.add_argument("--labels", action="append",
                    help="Labels CSV (frame_number;label). Repeatable; align with --pcap. If fewer than --pcap, missing are treated as no-attacks.")
    ap.add_argument("--outdir", default=".", help="Output directory")
    ap.add_argument("--outfile-base", default="summary_ALL",
                    help="Base name for aggregated outputs (no extension). Default: summary_ALL")
    ap.add_argument("--per-pair-csv", action="store_true",
                    help="Also write one structured CSV per (pcap,labels) pair: summary_<pcapbase>.csv")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    pcaps = args.pcap
    labels = args.labels or []
    if len(labels) > len(pcaps):
        raise SystemExit("ERROR: More --labels entries than --pcap entries.")
    # Align lists: pad labels with None
    labels = labels + [None] * (len(pcaps) - len(labels))

    # Validate existence
    for i, p in enumerate(pcaps):
        if not os.path.exists(p):
            raise SystemExit(f"PCAP not found: {p}")
        if labels[i] and not os.path.exists(labels[i]):
            raise SystemExit(f"Labels not found: {labels[i]}")

    os.makedirs(args.outdir, exist_ok=True)

    # Collect & compute per dataset
    df_apps = []  # to aggregate later across all datasets
    for i, (pcap_path, lab_path) in enumerate(zip(pcaps, labels), start=1):
        if args.verbose:
            tag = f"[{i}/{len(pcaps)}]"
            print(f"{tag} Loading: {pcap_path}" + (f" with labels {lab_path}" if lab_path else " (no labels)"))

        mal_frames = load_labels(lab_path, verbose=args.verbose)
        df = collect_packets(pcap_path, mal_frames, verbose=args.verbose)
        df_app = df[df["app"].apply(is_application_layer)].copy()
        df_apps.append(df_app)

        # Per-pair CSV for this dataset (structured only)
        if args.per_pair_cvv if False else args.per_pair_csv:  # typo guard
            pass
        if args.per_pair_csv:
            total_pairs, pairs_with_attacks = compute_pairs_overview(df_app)
            pair_counts = {"total_pairs": total_pairs, "pairs_with_attacks": pairs_with_attacks}
            interstats  = compute_interarrival_by_pair_app(df_app)
            base = os.path.splitext(os.path.basename(pcap_path))[0]
            out_struct = os.path.join(args.outdir, f"summary_{base}.csv")
            save_structured_csv(pair_counts, interstats, out_struct)
            if args.verbose:
                print(f"[per-pair] wrote {out_struct}")

    # Aggregate across ALL datasets
    if df_apps:
        df_all = pd.concat(df_apps, ignore_index=True)
    else:
        df_all = pd.DataFrame(columns=["frame","ts","src","dst","app","trans","length","is_mal"])

    total_pairs_all, pairs_with_attacks_all = compute_pairs_overview(df_all)
    pair_counts_all = {"total_pairs": total_pairs_all, "pairs_with_attacks": pairs_with_attacks_all}
    interstats_all  = compute_interarrival_by_pair_app(df_all)

    # Console + aggregated CSVs
    print_summary(pair_counts_all, interstats_all, header="== Aggregated across ALL datasets ==")
    out_struct_all = os.path.join(args.outdir, f"{args.outfile_base}.csv")
    out_pretty_all = os.path.join(args.outdir, f"{args.outfile_base}_pretty.csv")
    save_structured_csv(pair_counts_all, interstats_all, out_struct_all)
    save_pretty_csv(pair_counts_all, interstats_all, out_pretty_all)
    print(f"Saved aggregated CSV (structured) → {out_struct_all}")
    print(f"Saved aggregated CSV (pretty)     → {out_pretty_all}")
    print("Done.")

if __name__ == "__main__":
    main()

