#!/usr/bin/env python3
"""
task1d.py — CCDF plots for header & payload lengths per app protocol (NORMAL vs MALICIOUS)
------------------------------------------------------------------------------------------
python3 task1d.py \
  --pcap 'characterization_modbus_6RTU_with_operate (1).pcap' \
  --labels 'characterization_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'CnC_uploading_exe_modbus_6RTU_with_operate.pcap' \
  --labels 'CnC_uploading_exe_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'exploit_ms08_netapi_modbus_6RTU_with_operate.pcap' \
  --labels 'exploit_ms08_netapi_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'Modbus_polling_only_6RTU(2).pcap' \
  --labels 'Modbus_polling_only_6RTU_labeled.csv' \
  --pcap 'moving_two_files_modbus_6RTU.pcap' \
  --labels 'moving_two_files_modbus_6RTU_labeled.csv' \
  --pcap 'run1_12rtu_fixed.pcap' \
  --labels 'run1_12rtu_labeled.csv' \
  --pcap 'run11.pcap' \
  --labels 'run11_labeled.csv' \
  --pcap 'run1_3rtu_2s.pcap' \
  --labels 'run1_3rtu_2s_labeled (1).csv' \
  --pcap 'run1_6rtu(1).pcap' \
  --labels 'run1_6rtu_labeled.csv' \
  --pcap 'run8.pcap' \
  --labels 'run8_labeled.csv' \
  --pcap 'send_a_fake_command_modbus_6RTU_with_operate.pcap' \
  --labels 'send_a_fake_command_modbus_6RTU_with_operate_labeled (1).csv' \
  --outdir task1d_rez --outfile-base ALL --per-pair-csv --verbose

Notes:
- Y-axis is LINEAR.
- CCDF computed manually .
"""

import argparse
import os
import re
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pyshark


#helpers
INFRA_LAYERS = {
    "ETH", "ETHERNET", "LLC", "STP", "VLAN", "IP", "IPV6", "TCP", "UDP",
    "ICMP", "ICMPV6", "ARP", "NBNS", "SSDP", "MDNS", "DATA", "UNKNOWN"
}

def normalize_app(app: str) -> str:
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def is_application_layer(app: str) -> bool:
    return bool(app) and app.upper() not in INFRA_LAYERS

def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name.strip())

def load_labels(labels_path: str | None, verbose: bool = False) -> set[int]:
    if not labels_path:
        if verbose:
            print("No labels provided → all packets treated as NORMAL.")
        return set()
    df = pd.read_csv(labels_path, engine="python", sep=None, header=None)
    if df.shape[1] != 2:
        raise SystemExit("ERROR: labels CSV must have 2 columns: frame_number;label")
    df.columns = ["frame_number", "label"]
    mal = set(df.loc[df["label"] == 1, "frame_number"].astype(int).tolist())
    if verbose:
        print(f"Loaded labels: {len(df)} rows, {len(mal)} malicious frames")
    return mal

def estimate_header_payload_lengths(pkt):
    # Total frame length
    total_len = None
    # Prefer frame_info.len if present; fall back to pkt.length
    try:
        if hasattr(pkt, "frame_info") and hasattr(pkt.frame_info, "len"):
            total_len = int(pkt.frame_info.len)
        elif hasattr(pkt, "length"):
            total_len = int(pkt.length)
    except Exception:
        total_len = None
    if total_len is None:
        return None, None

    # Try TCP/UDP payload first
    payload_len = None
    try:
        if hasattr(pkt, "tcp") and hasattr(pkt.tcp, "len"):
            payload_len = int(pkt.tcp.len)
    except Exception:
        pass
    try:
        if payload_len is None and hasattr(pkt, "udp"):
            if hasattr(pkt.udp, "length"):
                payload_len = max(int(pkt.udp.length) - 8, 0)
    except Exception:
        pass

    # Heuristic fallback
    if payload_len is None:
        eth_hdr = 14
        try:
            if hasattr(pkt, "vlan"):
                eth_hdr += 4
        except Exception:
            pass

        ip_hdr = 0
        try:
            if hasattr(pkt, "ip") and hasattr(pkt.ip, "hdr_len"):
                ip_hdr = int(pkt.ip.hdr_len)
            elif hasattr(pkt, "ipv6"):
                ip_hdr = 40
        except Exception:
            pass

        trans_hdr = 0
        try:
            if hasattr(pkt, "tcp"):
                if hasattr(pkt.tcp, "hdr_len"):
                    trans_hdr = int(pkt.tcp.hdr_len)
                else:
                    trans_hdr = 20  # conservative fallback
            elif hasattr(pkt, "udp"):
                trans_hdr = 8
        except Exception:
            pass

        payload_len = max(total_len - (eth_hdr + ip_hdr + trans_hdr), 0)

    header_len = max(total_len - payload_len, 0)
    return header_len, payload_len

def ccdf(values):
    if not values:
        return np.array([]), np.array([])
    x = np.sort(np.asarray(values, dtype=float))
    n = x.size
    ranks = np.arange(1, n + 1, dtype=float)
    y = (n - ranks + 1) / n
    return x, y

def plot_ccdf_per_type(out_path, app, hdr_values, pay_values, subset):
    plt.figure(figsize=(8, 6), dpi=110)
    xh, yh = ccdf(hdr_values)
    xp, yp = ccdf(pay_values)

    if xh.size:
        plt.plot(xh, yh, label="Header Length")
    if xp.size:
        plt.plot(xp, yp, label="Payload Length")

    plt.xlabel("Bytes")
    plt.ylabel("CCDF (P(X ≥ x))")
    plt.title(f"{app} — {subset} Packets")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()

def summarize(app, subset, hdr_vals, pay_vals, dataset_tag):
    def stats(arr):
        if not arr:
            return dict(n=0, mean=np.nan, median=np.nan, p95=np.nan, p99=np.nan, max=np.nan)
        a = np.asarray(arr, dtype=float)
        return dict(
            n=int(a.size),
            mean=float(np.mean(a)),
            median=float(np.median(a)),
            p95=float(np.percentile(a, 95)),
            p99=float(np.percentile(a, 99)),
            max=float(np.max(a)),
        )

    h = stats(hdr_vals)
    p = stats(pay_vals)
    return {
        "dataset": dataset_tag,
        "app": app,
        "subset": subset,
        "n": h["n"],  # number of samples (hdr/pay same count after filtering)
        "hdr_mean": h["mean"],
        "hdr_median": h["median"],
        "hdr_p95": h["p95"],
        "hdr_p99": h["p99"],
        "hdr_max": h["max"],
        "pay_mean": p["mean"],
        "pay_median": p["median"],
        "pay_p95": p["p95"],
        "pay_p99": p["p99"],
        "pay_max": p["max"],
    }

def process_one_pair(pcap_path, labels_path, outdir, per_pair_csv, verbose=False):
    base = os.path.splitext(os.path.basename(pcap_path))[0]
    out_subdir = os.path.join(outdir, f"{base}_ccdf_plots")
    os.makedirs(out_subdir, exist_ok=True)

    # Load labels
    mal_frames = load_labels(labels_path, verbose=verbose)
    has_mal = len(mal_frames) > 0

    # Per-app accumulators
    hdr_norm, pay_norm = defaultdict(list), defaultdict(list)
    hdr_mal,  pay_mal  = defaultdict(list), defaultdict(list)

    cap = pyshark.FileCapture(pcap_path, keep_packets=False)
    total = 0
    try:
        for pkt in cap:
            total += 1
            app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
            if not is_application_layer(app):
                continue

            # Frame number for label join
            try:
                frame = int(getattr(pkt, "number", total))
            except Exception:
                frame = total

            is_mal = frame in mal_frames
            hlen, plen = estimate_header_payload_lengths(pkt)
            if hlen is None or plen is None:
                continue

            if is_mal:
                hdr_mal[app].append(hlen)
                pay_mal[app].append(plen)
            else:
                hdr_norm[app].append(hlen)
                pay_norm[app].append(plen)
    finally:
        cap.close()

    # Plots per app
    apps = sorted(set(hdr_norm.keys()) | set(hdr_mal.keys()) | set(pay_norm.keys()) | set(pay_mal.keys()))
    if verbose:
        print(f"\n=== Task 1(d) CCDF Plots (Linear) for {base} ===")
    for app in apps:
        norm_hdr, norm_pay = hdr_norm.get(app, []), pay_norm.get(app, [])
        if norm_hdr or norm_pay:
            out_norm = os.path.join(out_subdir, f"{safe_name(app)}_ccdf_normal.png")
            plot_ccdf_per_type(out_norm, app, norm_hdr, norm_pay, "NORMAL")
            if verbose:
                print(f"  NORMAL   → {out_norm}")
        if has_mal:
            mal_hdr, mal_pay = hdr_mal.get(app, []), pay_mal.get(app, [])
            if mal_hdr or mal_pay:
                out_mal = os.path.join(out_subdir, f"{safe_name(app)}_ccdf_malicious.png")
                plot_ccdf_per_type(out_mal, app, mal_hdr, mal_pay, "MALICIOUS")
                if verbose:
                    print(f"  MALICIOUS→ {out_mal}")

    # CSV summary (per pair)
    pair_rows = []
    for app in apps:
        if hdr_norm.get(app) or pay_norm.get(app):
            pair_rows.append(summarize(app, "NORMAL", hdr_norm[app], pay_norm[app], base))
        if hdr_mal.get(app) or pay_mal.get(app):
            pair_rows.append(summarize(app, "MALICIOUS", hdr_mal[app], pay_mal[app], base))

    if per_pair_csv and pair_rows:
        df_pair = pd.DataFrame(pair_rows)
        csv_path = os.path.join(outdir, f"summary_{safe_name(base)}.csv")
        df_pair.to_csv(csv_path, index=False)
        if verbose:
            print(f"  CSV      → {csv_path}")

    # Return for global aggregation
    return hdr_norm, pay_norm, hdr_mal, pay_mal

def merge_app_maps(dst_map, src_map):
    for app, vals in src_map.items():
        dst_map[app].extend(vals)

def main():
    ap = argparse.ArgumentParser(description="Task 1(d): CCDF plots per app (linear scale) with multi-dataset support")
    # Accept multiple --pcap and --labels; the i-th labels corresponds to the i-th pcap
    ap.add_argument("--pcap", action="append", required=True,
                    help="Path to a PCAP file. Repeatable; order must match corresponding --labels (if any).")
    ap.add_argument("--labels", action="append",
                    help="Path to labels CSV for the matching --pcap. Repeatable; can be fewer than --pcap (missing treated as no labels).")
    ap.add_argument("--outdir", default="task1d",
                    help="Output directory.")
    ap.add_argument("--outfile-base", default="summary_ALL",
                    help="Base filename (without extension) for the aggregated CSV across all inputs.")
    ap.add_argument("--per-pair-csv", action="store_true",
                    help="Also write one CSV per (pcap, labels) pair (named after the pcap base).")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    pcaps = args.pcap
    labels_list = args.labels or []
    # Normalize labels list to same length as pcaps (pad with None)
    if len(labels_list) < len(pcaps):
        labels_list = labels_list + [None] * (len(pcaps) - len(labels_list))
    elif len(labels_list) > len(pcaps):
        raise SystemExit("ERROR: You provided more --labels than --pcap entries. Make them align by order.")

    os.makedirs(args.outdir, exist_ok=True)

    # Global accumulators across ALL datasets
    g_hdr_norm, g_pay_norm = defaultdict(list), defaultdict(list)
    g_hdr_mal,  g_pay_mal  = defaultdict(list), defaultdict(list)

    # Process each pair
    for pcap_path, labels_path in zip(pcaps, labels_list):
        if args.verbose:
            base = os.path.basename(pcap_path)
            print(f"\n[processing] {base}  (labels: {os.path.basename(labels_path) if labels_path else 'NONE'})")

        hN, pN, hM, pM = process_one_pair(
            pcap_path=pcap_path,
            labels_path=labels_path,
            outdir=args.outdir,
            per_pair_csv=args.per_pair_csv,
            verbose=args.verbose
        )

        # Merge into global
        merge_app_maps(g_hdr_norm, hN)
        merge_app_maps(g_pay_norm, pN)
        merge_app_maps(g_hdr_mal,  hM)
        merge_app_maps(g_pay_mal,  pM)

    # Global plots across ALL inputs
    all_subdir = os.path.join(args.outdir, "ALL_ccdf_plots")
    os.makedirs(all_subdir, exist_ok=True)

    all_apps = sorted(set(g_hdr_norm.keys()) | set(g_hdr_mal.keys()) | set(g_pay_norm.keys()) | set(g_pay_mal.keys()))
    has_any_mal = any(len(v) for v in g_hdr_mal.values()) or any(len(v) for v in g_pay_mal.values())

    if args.verbose:
        print(f"\n=== Combined CCDF Plots (Linear) across ALL inputs ===")
    for app in all_apps:
        norm_hdr, norm_pay = g_hdr_norm.get(app, []), g_pay_norm.get(app, [])
        if norm_hdr or norm_pay:
            out_norm = os.path.join(all_subdir, f"{safe_name(app)}_ccdf_normal.png")
            plot_ccdf_per_type(out_norm, app, norm_hdr, norm_pay, "NORMAL")
            if args.verbose:
                print(f"  NORMAL   → {out_norm}")
        if has_any_mal:
            mal_hdr, mal_pay = g_hdr_mal.get(app, []), g_pay_mal.get(app, [])
            if mal_hdr or mal_pay:
                out_mal = os.path.join(all_subdir, f"{safe_name(app)}_ccdf_malicious.png")
                plot_ccdf_per_type(out_mal, app, mal_hdr, mal_pay, "MALICIOUS")
                if args.verbose:
                    print(f"  MALICIOUS→ {out_mal}")

    # Aggregated CSV across ALL inputs
    rows = []
    for app in all_apps:
        if g_hdr_norm.get(app) or g_pay_norm.get(app):
            rows.append(summarize(app, "NORMAL", g_hdr_norm[app], g_pay_norm[app], "ALL"))
        if g_hdr_mal.get(app) or g_pay_mal.get(app):
            rows.append(summarize(app, "MALICIOUS", g_hdr_mal[app], g_pay_mal[app], "ALL"))
    if rows:
        df_all = pd.DataFrame(rows)
        all_csv = os.path.join(args.outdir, f"{safe_name(args.outfile_base)}.csv")
        df_all.to_csv(all_csv, index=False)
        if args.verbose:
            print(f"\nAggregated CSV → {all_csv}")

    if args.verbose:
        print("\nDone.")

if __name__ == "__main__":
    main()
