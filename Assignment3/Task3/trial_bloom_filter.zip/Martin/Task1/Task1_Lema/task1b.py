#!/usr/bin/env python3
"""
task1b_multi.py — Task 1(b): Length & Inter-Arrival stats (multi (pcap,labels) pairs)

python3 task1b.py \
  --pcap 'characterization_modbus_6RTU_with_operate (1).pcap' \
  --labels 'characterization_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'CnC_uploading_exe_modbus_6RTU_with_operate.pcap' \
  --labels 'CnC_uploading_exe_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'exploit_ms08_netapi_modbus_6RTU_with_operate.pcap' \
  --labels 'exploit_ms08_netapi_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'Modbus_polling_only_6RTU(2).pcap' \
  --labels 'Modbus_polling_only_6RTU_labeled.csv' \
  --pcap 'moving_two_files_modbus_6RTU.pcap' \
  --labels 'moving_two_files_modbus_6RTU_labeled.csv' \
  --pcap 'run1_12rtu_fixed.pcap' \
  --labels 'run1_12rtu_labeled.csv' \
  --pcap 'run11.pcap' \
  --labels 'run11_labeled.csv' \
  --pcap 'run1_3rtu_2s.pcap' \
  --labels 'run1_3rtu_2s_labeled (1).csv' \
  --pcap 'run1_6rtu(1).pcap' \
  --labels 'run1_6rtu_labeled.csv' \
  --pcap 'run8.pcap' \
  --labels 'run8_labeled.csv' \
  --pcap 'send_a_fake_command_modbus_6RTU_with_operate.pcap' \
  --labels 'send_a_fake_command_modbus_6RTU_with_operate_labeled (1).csv' \
  --outdir task1b_rez --outfile-base ALL --per-pair-csv --verbose

"""

import argparse
import os
import numpy as np
import pandas as pd
import pyshark
from typing import List, Set

# Helpers

INFRA_LAYERS = {
    "ETH", "ETHERNET", "LLC", "STP", "VLAN", "IP", "IPV6", "TCP", "UDP",
    "ICMP", "ICMPV6", "ARP", "NBNS", "SSDP", "MDNS", "DATA", "UNKNOWN"
}

def normalize_app(app):
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def is_application_layer(app):
    if not app:
        return False
    return app.upper() not in INFRA_LAYERS


# Label loading

def load_labels(labels_path: str, verbose: bool=False) -> Set[int]:
    if not labels_path:
        if verbose:
            print("No labels provided -> treating all packets as NORMAL (no attacks).")
        return set()
    df = pd.read_csv(labels_path, engine="python", sep=None, header=None)
    if df.shape[1] != 2:
        raise SystemExit("ERROR: labels CSV must have 2 columns: frame_number;label")
    df.columns = ["frame_number", "label"]
    mal = set(df.loc[df["label"] == 1, "frame_number"].astype(int).tolist())
    if verbose:
        print(f"Loaded labels: {len(df)} rows, {len(mal)} malicious from {os.path.basename(labels_path)}")
    return mal


# Packet capture → DataFrame
def collect_packets(pcap_path: str, mal_frames: Set[int], progress_every: int=1_000_000, verbose: bool=False) -> pd.DataFrame:
    cap = pyshark.FileCapture(pcap_path, keep_packets=False)
    rows = []
    n = 0
    for pkt in cap:
        n += 1
        if progress_every and (n % progress_every == 0):
            print(f"[{os.path.basename(pcap_path)}] processed {n:,} packets...")

        # frame number and malicious flag
        try:
            frame = int(getattr(pkt, "number", 0))
        except Exception:
            frame = 0
        is_mal = frame in mal_frames

        # timestamp
        try:
            ts = float(pkt.sniff_time.timestamp())
        except Exception:
            ts = None

        # addresses
        src = dst = None
        if hasattr(pkt, "ip"):
            src, dst = pkt.ip.src, pkt.ip.dst
        elif hasattr(pkt, "ipv6"):
            src, dst = pkt.ipv6.src, pkt.ipv6.dst

        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        trans = getattr(pkt, "transport_layer", None) or "UNKNOWN"

        # frame length as proxy; pyshark sometimes exposes "length"
        try:
            length = int(pkt.length)
        except Exception:
            try:
                length = int(pkt.frame_info.len)
            except Exception:
                length = None

        rows.append((frame, ts, src, dst, app, trans, length, is_mal))

    cap.close()
    df = pd.DataFrame(rows, columns=["frame","ts","src","dst","app","trans","length","is_mal"])
    if verbose:
        print(f"[{os.path.basename(pcap_path)}] captured packets: {len(df):,}")
    return df

# Length statistics
def compute_length_stats(df_app: pd.DataFrame):
    g_all = df_app.groupby("app")["length"]
    all_ = g_all.agg(count="count", mean="mean", std="std", median="median").reset_index()
    all_.insert(1, "subset", "ALL")

    df_norm = df_app[~df_app["is_mal"]]
    df_mal  = df_app[df_app["is_mal"]]

    norm = pd.DataFrame()
    mal  = pd.DataFrame()

    if not df_norm.empty:
        g = df_norm.groupby("app")["length"]
        norm = g.agg(count="count", mean="mean", std="std", median="median").reset_index()
        norm.insert(1, "subset", "NORMAL")

    if not df_mal.empty:
        g = df_mal.groupby("app")["length"]
        mal = g.agg(count="count", mean="mean", std="std", median="median").reset_index()
        mal.insert(1, "subset", "MALICIOUS")

    return all_, norm, mal

# Inter-arrival (pair+app)

def compute_interarrival_pair_app(df_app: pd.DataFrame):
    df = df_app.dropna(subset=["ts","src","dst"]).copy()
    if df.empty:
        return {k: pd.DataFrame() for k in [
            "pair_all","pair_normal_strict","pair_m_strict","app_all","app_normal_strict","app_m_strict"
        ]}

    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    df = df.sort_values(["pair","app","ts"])
    groups = df.groupby(["pair","app"], sort=False)
    rows_all, rows_norm, rows_mal = [], [], []

    for (pair, app), g in groups:
        ts = g["ts"].to_numpy(float)
        is_m = g["is_mal"].to_numpy()
        is_n = ~is_m
        if len(ts) < 2: 
            continue

        # ALL
        d = np.diff(ts)
        rows_all.append((pair[0],pair[1],app,"ALL",len(d),float(np.mean(d)),
                         float(np.std(d,ddof=1)) if len(d)>1 else 0.0,float(np.median(d))))

        # NORMAL strict
        n_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_n[i] and is_n[i+1]]
        if n_d:
            n_d = np.array(n_d,float)
            rows_norm.append((pair[0],pair[1],app,"NORMAL_strict",len(n_d),
                              float(np.mean(n_d)),float(np.std(n_d,ddof=1)) if len(n_d)>1 else 0.0,
                              float(np.median(n_d))))

        # MALICIOUS strict
        m_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_m[i] and is_m[i+1]]
        if m_d:
            m_d = np.array(m_d,float)
            rows_mal.append((pair[0],pair[1],app,"MALICIOUS_strict",len(m_d),
                             float(np.mean(m_d)),float(np.std(m_d,ddof=1)) if len(m_d)>1 else 0.0,
                             float(np.median(m_d))))

    cols = ["src","dst","app","subset","count","mean","std","median"]
    df_all  = pd.DataFrame(rows_all,  columns=cols)
    df_norm = pd.DataFrame(rows_norm, columns=cols)
    df_mal  = pd.DataFrame(rows_mal,  columns=cols)

    # Aggregate across pairs → per app
    def agg(df, name):
        if df.empty: 
            return pd.DataFrame(columns=["app","subset","count","mean","std","median"])
        g = df.groupby("app",as_index=False)
        rows=[]
        for app,grp in g:
            c=int(grp["count"].sum())
            m=(grp["count"]*grp["mean"]).sum()/max(c,1)
            s=np.sqrt(((grp["count"]*(grp["std"]**2)).sum())/max(c-1,1)) if c>1 else 0.0
            med=(grp["count"]*grp["median"]).sum()/max(c,1)
            rows.append((app,name,c,m,s,med))
        return pd.DataFrame(rows,columns=["app","subset","count","mean","std","median"])

    return {
        "pair_all":df_all,
        "pair_normal_strict":df_norm,
        "pair_m_strict":df_mal,
        "app_all":agg(df_all,"ALL"),
        "app_normal_strict":agg(df_norm,"NORMAL_strict"),
        "app_m_strict":agg(df_mal,"MALICIOUS_strict")
    }


# Inter-arrival (pair-only)

def compute_interarrival_pair_only(df_app: pd.DataFrame):
    df = df_app.dropna(subset=["ts","src","dst"]).copy()
    if df.empty:
        return {"pair_all": pd.DataFrame(), "pair_normal_strict": pd.DataFrame(), "pair_m_strict": pd.DataFrame()}

    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    df = df.sort_values(["pair","ts"])
    rows_all, rows_norm, rows_mal = [], [], []

    for pair, g in df.groupby("pair", sort=False):
        ts = g["ts"].to_numpy(float)
        is_m = g["is_mal"].to_numpy()
        is_n = ~is_m
        if len(ts) < 2:
            continue

        d = np.diff(ts)
        rows_all.append((pair[0],pair[1],"ALL",len(d),float(np.mean(d)),
                         float(np.std(d,ddof=1)) if len(d)>1 else 0.0,float(np.median(d))))

        n_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_n[i] and is_n[i+1]]
        if n_d:
            n_d = np.array(n_d,float)
            rows_norm.append((pair[0],pair[1],"NORMAL_strict",len(n_d),
                              float(np.mean(n_d)),float(np.std(n_d,ddof=1)) if len(n_d)>1 else 0.0,
                              float(np.median(n_d))))

        m_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_m[i] and is_m[i+1]]
        if m_d:
            m_d = np.array(m_d,float)
            rows_mal.append((pair[0],pair[1],"MALICIOUS_strict",len(m_d),
                             float(np.mean(m_d)),float(np.std(m_d,ddof=1)) if len(m_d)>1 else 0.0,
                             float(np.median(m_d))))

    cols = ["src","dst","subset","count","mean","std","median"]
    return {
        "pair_all": pd.DataFrame(rows_all, columns=cols),
        "pair_normal_strict": pd.DataFrame(rows_norm, columns=cols),
        "pair_m_strict": pd.DataFrame(rows_mal, columns=cols),
    }

# Save structured CSV

def save_structured(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app,outdir,base_name):
    os.makedirs(outdir,exist_ok=True)
    path=os.path.join(outdir,f"{base_name}.csv")
    rows=[]
    def add(df,sec):
        if df.empty: return
        for _,r in df.iterrows():
            rows.append({
                "section":sec,
                "app_protocol":r.get("app",""),
                "src_ip":r.get("src",""),
                "dst_ip":r.get("dst",""),
                "subset":r.get("subset",""),
                "count":r.get("count",""),
                "mean":r.get("mean",""),
                "std":r.get("std",""),
                "median":r.get("median","")
            })
    # Lengths
    add(length_all,"length_app_overall")
    add(length_norm,"length_app_normal")
    add(length_mal,"length_app_malicious")
    # Inter-arrival: pair-only (1b)
    add(inter_pair_only["pair_all"],"interarrival_pairONLY_all")
    add(inter_pair_only["pair_normal_strict"],"interarrival_pairONLY_normal_strict")
    add(inter_pair_only["pair_m_strict"],"interarrival_pairONLY_malicious_strict")
    # Inter-arrival: pair+app (1c-style view, helpful context)
    add(inter_pair_app["pair_all"],"interarrival_pairAPP_all")
    add(inter_pair_app["pair_normal_strict"],"interarrival_pairAPP_normal_strict")
    add(inter_pair_app["pair_m_strict"],"interarrival_pairAPP_malicious_strict")
    # Per-app aggregates from pair+app
    add(inter_pair_app["app_all"],"interarrival_app_all")
    add(inter_pair_app["app_normal_strict"],"interarrival_app_normal_strict")
    add(inter_pair_app["app_m_strict"],"interarrival_app_malicious_strict")

    pd.DataFrame(rows).to_csv(path,index=False)
    return path


# Pretty CSV & print summary

def _block_lengths(df,title):
    lines=[f"Packet length (bytes) — only packets WITH application data ({title}):"]
    if df.empty: lines.append("  (none)")
    else:
        for _,r in df.sort_values(["app"]).iterrows():
            lines.append(f"  {r['app']}: count={int(r['count'])}, mean={r['mean']:.3f} B, "
                         f"std={0 if pd.isna(r['std']) else r['std']:.3f} B, median={r['median']:.3f} B")
    lines.append("")
    return lines

def _block_pairs_pair_only(df,title):
    lines=[f"Inter-arrival time (s) — same unordered host pair — {title}:"]
    if df.empty: lines.append("  (none)")
    else:
        for _,r in df.sort_values(["src","dst"]).iterrows():
            lines.append(f"  {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                         f"mean={r['mean']:.6f}s, std={0 if pd.isna(r['std']) else r['std']:.6f}s, "
                         f"median={r['median']:.6f}s")
    lines.append("")
    return lines

def _block_pairs_pair_app(df,title):
    lines=[f"Inter-arrival time (s) — same unordered host pair AND same app — {title}:"]
    if df.empty: lines.append("  (none)")
    else:
        for _,r in df.sort_values(["app","src","dst"]).iterrows():
            lines.append(f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                         f"mean={r['mean']:.6f}s, std={0 if pd.isna(r['std']) else r['std']:.6f}s, "
                         f"median={r['median']:.6f}s")
    lines.append("")
    return lines

def save_pretty(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app,outdir,base_name):
    path=os.path.join(outdir,f"{base_name}_pretty.csv")
    lines=["=== Task 1(b) Summary ===",""]
    lines+=_block_lengths(length_all,"ALL")
    lines+=_block_lengths(length_norm,"NORMAL")
    lines+=_block_lengths(length_mal,"MALICIOUS")
    # pair-only
    lines+=_block_pairs_pair_only(inter_pair_only["pair_all"],"ALL packets")
    lines+=_block_pairs_pair_only(inter_pair_only["pair_normal_strict"],"NORMAL_strict (two consecutive normal packets)")
    lines+=_block_pairs_pair_only(inter_pair_only["pair_m_strict"],"MALICIOUS_strict (two consecutive malicious packets)")
    # pair+app
    lines+=_block_pairs_pair_app(inter_pair_app["pair_all"],"ALL packets")
    lines+=_block_pairs_pair_app(inter_pair_app["pair_normal_strict"],"NORMAL_strict (two consecutive normal packets)")
    lines+=_block_pairs_pair_app(inter_pair_app["pair_m_strict"],"MALICIOUS_strict (two consecutive malicious packets)")
    pd.DataFrame({"text":lines}).to_csv(path,index=False)
    return path

def print_summary(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app, header=None):
    if header:
        print(f"\n===== {header} =====")
    print("\n=== Task 1(b) Summary ===")
    # Lengths
    for block in _block_lengths(length_all,"ALL"): print(block)
    for block in _block_lengths(length_norm,"NORMAL"): print(block)
    for block in _block_lengths(length_mal,"MALICIOUS"): print(block)
    # Pair-only
    for block in _block_pairs_pair_only(inter_pair_only["pair_all"],"ALL packets"): print(block)
    for block in _block_pairs_pair_only(inter_pair_only["pair_normal_strict"],"NORMAL_strict (two consecutive normal packets)"): print(block)
    for block in _block_pairs_pair_only(inter_pair_only["pair_m_strict"],"MALICIOUS_strict (two consecutive malicious packets)"): print(block)
    # Pair+app
    for block in _block_pairs_pair_app(inter_pair_app["pair_all"],"ALL packets"): print(block)
    for block in _block_pairs_pair_app(inter_pair_app["pair_normal_strict"],"NORMAL_strict (two consecutive normal packets)"): print(block)
    for block in _block_pairs_pair_app(inter_pair_app["pair_m_strict"],"MALICIOUS_strict (two consecutive malicious packets)"): print(block)


# Main
def main():
    ap = argparse.ArgumentParser(description="Task 1(b): Length & Inter-arrival stats over multiple (pcap,labels) pairs")
    ap.add_argument("--pcap", action="append", required=True,
                    help="Path to a PCAP. Repeat for multiple datasets, order must match --labels (if provided).")
    ap.add_argument("--labels", action="append",
                    help="Path to a labels CSV for the preceding --pcap. Omit an entry to treat as all-normal.")
    ap.add_argument("--outdir", default="task1b", help="Output directory (created if missing).")
    ap.add_argument("--outfile-base", default="summary_ALL",
                    help="Base filename (without extension) for aggregated outputs.")
    ap.add_argument("--per-pair-csv", action="store_true",
                    help="If set, also write per-pair CSVs named after each pcap base.")
    ap.add_argument("--progress-every", type=int, default=1_000_000,
                    help="Print a packet counter every N packets per PCAP (0 disables).")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    pcaps: List[str] = args.pcap
    labels_list: List[str] = args.labels or []

    # Normalize labels length to pcaps length (missing entries -> None)
    if len(labels_list) < len(pcaps):
        labels_list = labels_list + [None] * (len(pcaps) - len(labels_list))
    elif len(labels_list) > len(pcaps):
        raise SystemExit("ERROR: more --labels than --pcap. Provide one label (or omit) per pcap, in order.")

    # Validate paths
    for i, p in enumerate(pcaps):
        if not os.path.exists(p):
            raise SystemExit(f"PCAP not found: {p}")
        lab = labels_list[i]
        if lab and not os.path.exists(lab):
            raise SystemExit(f"Labels not found for {p}: {lab}")

    os.makedirs(args.outdir, exist_ok=True)

    # Process each pair, collect per-pair DFS, and concatenate for ALL
    all_frames = []
    for pcap, lab in zip(pcaps, labels_list):
        mal = load_labels(lab, verbose=args.verbose)
        df = collect_packets(pcap, mal, progress_every=args.progress_every, verbose=args.verbose)

        # Keep only packets that report an application layer
        df_app = df[df["app"].apply(is_application_layer)].copy()
        # (Optional stricter payload filtering could be added if payload field is accessible)

        # Per-pair metrics
        length_all, length_norm, length_mal = compute_length_stats(df_app)
        inter_pair_only = compute_interarrival_pair_only(df_app)   # 1(b)
        inter_pair_app  = compute_interarrival_pair_app(df_app)    # helpful context

        # Print and save per-pair if requested
        base = os.path.splitext(os.path.basename(pcap))[0]
        if args.per_pair_csv:  # keep arg name exact
            print_summary(length_all, length_norm, length_mal, inter_pair_only, inter_pair_app,
                          header=f"Per-pair: {base}")
            p1 = save_structured(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app,
                                 args.outdir, f"summary_{base}")
            p2 = save_pretty(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app,
                              args.outdir, f"summary_pretty_{base}")
            print(f"Saved per-pair CSVs → {p1}")
            print(f"Saved per-pair CSVs → {p2}")

        # For ALL aggregation
        all_frames.append(df_app)

    # Aggregate across ALL pairs
    if not all_frames:
        print("No data to aggregate. Exiting.")
        return
    df_all = pd.concat(all_frames, ignore_index=True)

    length_all, length_norm, length_mal = compute_length_stats(df_all)
    inter_pair_only = compute_interarrival_pair_only(df_all)   # 1(b)
    inter_pair_app  = compute_interarrival_pair_app(df_all)    # context

    print_summary(length_all, length_norm, length_mal, inter_pair_only, inter_pair_app,
                  header="AGGREGATED OVER ALL INPUTS")

    out1 = save_structured(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app,
                           args.outdir, args.outfile_base)
    out2 = save_pretty(length_all,length_norm,length_mal,inter_pair_only,inter_pair_app,
                       args.outdir, f"{args.outfile_base}")
    print(f"\nSaved aggregated CSV (structured) → {out1}")
    print(f"Saved aggregated CSV (pretty)     → {out2}")
    print("Done.")

if __name__ == "__main__":
    main()

