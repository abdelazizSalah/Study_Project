#!/usr/bin/env python3
"""
task1a.py — Task 1(a): Dataset Characterization (multi-pcap, per-pair CSVs)
----------------------------------------------------------------------------
python3 task1a.py \
  --pcap 'characterization_modbus_6RTU_with_operate (1).pcap' \
  --labels 'characterization_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'CnC_uploading_exe_modbus_6RTU_with_operate.pcap' \
  --labels 'CnC_uploading_exe_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'exploit_ms08_netapi_modbus_6RTU_with_operate.pcap' \
  --labels 'exploit_ms08_netapi_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'Modbus_polling_only_6RTU(2).pcap' \
  --labels 'Modbus_polling_only_6RTU_labeled.csv' \
  --pcap 'moving_two_files_modbus_6RTU.pcap' \
  --labels 'moving_two_files_modbus_6RTU_labeled.csv' \
  --pcap 'run1_12rtu_fixed.pcap' \
  --labels 'run1_12rtu_labeled.csv' \
  --pcap 'run11.pcap' \
  --labels 'run11_labeled.csv' \
  --pcap 'run1_3rtu_2s.pcap' \
  --labels 'run1_3rtu_2s_labeled (1).csv' \
  --pcap 'run1_6rtu(1).pcap' \
  --labels 'run1_6rtu_labeled.csv' \
  --pcap 'run8.pcap' \
  --labels 'run8_labeled.csv' \
  --pcap 'send_a_fake_command_modbus_6RTU_with_operate.pcap' \
  --labels 'send_a_fake_command_modbus_6RTU_with_operate_labeled (1).csv' \
  --outdir task1a_rez --outfile-base ALL --per-pair-csv --verbose
"""

import argparse
import os
from collections import Counter, defaultdict

import pandas as pd
import pyshark



# Labels loader

def load_labels(labels_path):
    # Auto-detect delimiter; expects exactly two columns: frame_number;label
    df = pd.read_csv(labels_path, engine="python", sep=None, header=None)
    if df.shape[1] != 2:
        raise SystemExit(
            f"ERROR: labels file must have exactly two columns (frame_number;label), found {df.shape[1]}"
        )
    df.columns = ["frame_number", "label"]
    malicious_frames = set(df.loc[df["label"] == 1, "frame_number"].astype(int).tolist())
    return malicious_frames, len(df)


# PCAP analyzer (single pair)

def analyze_pcap(pcap_path, malicious_frames, verbose=False):
    cap = pyshark.FileCapture(pcap_path, keep_packets=False)

    total_packets = 0
    seen_frames = set()

    app_counter = Counter()
    app_counter_attack = Counter()
    trans_counter = Counter()
    trans_counter_attack = Counter()
    app_trans = defaultdict(lambda: Counter())
    app_trans_attack = defaultdict(lambda: Counter())

    for pkt in cap:
        total_packets += 1
        if verbose and (total_packets % 1_000_000 == 0):
            print(f"[{pcap_path}] processed {total_packets:,} packets...")

        # Frame number (fallback to running counter if missing)
        try:
            frame_no = int(pkt.number)
        except Exception:
            frame_no = total_packets
        seen_frames.add(frame_no)

        # Label membership for this frame
        is_mal = frame_no in malicious_frames

        # Application & transport
        app = getattr(pkt, "highest_layer", "UNKNOWN") or "UNKNOWN"
        trans = getattr(pkt, "transport_layer", None) or "N/A"   # clean missing transport

        # Totals
        app_counter[app] += 1
        trans_counter[trans] += 1
        app_trans[app][trans] += 1

        if is_mal:
            app_counter_attack[app] += 1
            trans_counter_attack[trans] += 1
            app_trans_attack[app][trans] += 1

    cap.close()

    # Count only malicious frames that actually appeared in this PCAP
    malicious_in_pcap = len(malicious_frames & seen_frames)
    normal_in_pcap = total_packets - malicious_in_pcap

    return {
        "total_packets": total_packets,
        "malicious_packets": malicious_in_pcap,
        "normal_packets": normal_in_pcap,
        "app_counter": app_counter,
        "app_counter_attack": app_counter_attack,
        "trans_counter": trans_counter,
        "trans_counter_attack": trans_counter_attack,
        "app_trans": app_trans,
        "app_trans_attack": app_trans_attack,
    }



# Aggregation helpers

def merge_stats(acc, cur):
    """Sum counters and nested counters into acc."""
    if not acc:
        # shallow copy for the first item
        return {
            "total_packets": cur["total_packets"],
            "malicious_packets": cur["malicious_packets"],
            "normal_packets": cur["normal_packets"],
            "app_counter": Counter(cur["app_counter"]),
            "app_counter_attack": Counter(cur["app_counter_attack"]),
            "trans_counter": Counter(cur["trans_counter"]),
            "trans_counter_attack": Counter(cur["trans_counter_attack"]),
            "app_trans": defaultdict(Counter, {a: Counter(td) for a, td in cur["app_trans"].items()}),
            "app_trans_attack": defaultdict(Counter, {a: Counter(td) for a, td in cur["app_trans_attack"].items()}),
        }

    acc["total_packets"] += cur["total_packets"]
    acc["malicious_packets"] += cur["malicious_packets"]
    acc["normal_packets"] += cur["normal_packets"]

    acc["app_counter"].update(cur["app_counter"])
    acc["app_counter_attack"].update(cur["app_counter_attack"])
    acc["trans_counter"].update(cur["trans_counter"])
    acc["trans_counter_attack"].update(cur["trans_counter_attack"])

    for app, tdict in cur["app_trans"].items():
        acc["app_trans"][app].update(tdict)
    for app, tdict in cur["app_trans_attack"].items():
        acc["app_trans_attack"][app].update(tdict)

    return acc


# CSV writer

def save_structured_csv(stats, outdir, outfile_base="ALL"):
    os.makedirs(outdir, exist_ok=True)
    csv_path = os.path.join(outdir, f"summary_{outfile_base}.csv")

    rows = []
    total = stats["total_packets"] or 1  # avoid div by zero

    # summary rows
    rows += [
        {"section": "summary", "app_protocol": "total_packets", "transport_protocol": "",
         "count": stats["total_packets"], "fraction_of_total": 1.0, "fraction_within_app": ""},
        {"section": "summary", "app_protocol": "malicious_packets", "transport_protocol": "",
         "count": stats["malicious_packets"], "fraction_of_total": stats["malicious_packets"]/total, "fraction_within_app": ""},
        {"section": "summary", "app_protocol": "normal_packets", "transport_protocol": "",
         "count": stats["normal_packets"], "fraction_of_total": stats["normal_packets"]/total, "fraction_within_app": ""},
    ]

    # app / transport counters
    for section, counter in (
        ("app_overall", stats["app_counter"]),
        ("app_malicious", stats["app_counter_attack"]),
        ("transport_overall", stats["trans_counter"]),
        ("transport_malicious", stats["trans_counter_attack"]),
    ):
        for key, val in sorted(counter.items()):
            rows.append({
                "section": section,
                "app_protocol": key if "app" in section else "",
                "transport_protocol": key if "transport" in section else "",
                "count": int(val),
                "fraction_of_total": (val / total),
                "fraction_within_app": "",
            })

    # app_transport (overall & malicious)
    for section, mapping in (
        ("app_transport_overall", stats["app_trans"]),
        ("app_transport_malicious", stats["app_trans_attack"]),
    ):
        for app in sorted(mapping.keys()):
            tdict = mapping[app]
            app_total = sum(tdict.values()) or 1
            for tr, cnt in sorted(tdict.items()):
                rows.append({
                    "section": section,
                    "app_protocol": app,
                    "transport_protocol": tr,
                    "count": int(cnt),
                    "fraction_of_total": (cnt / total),
                    "fraction_within_app": (cnt / app_total),
                })

    pd.DataFrame(rows).to_csv(csv_path, index=False)
    return csv_path



# Console summary (aggregated)

def print_summary(stats):
    print("\n=== Task 1(a) Aggregated Summary (ALL pairs) ===")
    print(f"Total packets:     {stats['total_packets']}")
    print(f"Malicious packets: {stats['malicious_packets']}")
    print(f"Normal packets:    {stats['normal_packets']}\n")

    total = stats["total_packets"] or 1

    print("Application-layer protocols (overall):")
    for k in sorted(stats["app_counter"].keys()):
        v = stats["app_counter"][k]
        print(f"  {k}: {v} ({v/total*100:.2f}%)")

    print("\nApplication-layer protocols (malicious):")
    for k in sorted(stats["app_counter_attack"].keys()):
        v = stats["app_counter_attack"][k]
        print(f"  {k}: {v} ({v/total*100:.2f}% of total)")

    print("\nTransport-layer protocols (overall):")
    for k in sorted(stats["trans_counter"].keys()):
        v = stats["trans_counter"][k]
        print(f"  {k}: {v} ({v/total*100:.2f}%)")

    print("\nTransport-layer protocols (malicious):")
    for k in sorted(stats["trans_counter_attack"].keys()):
        v = stats["trans_counter_attack"][k]
        print(f"  {k}: {v} ({v/total*100:.2f}% of total)")

    print("\nPer-application breakdown by transport (overall):")
    for app in sorted(stats["app_trans"].keys()):
        tdict = stats["app_trans"][app]
        app_total = sum(tdict.values()) or 1
        print(f"  {app}:")
        for tr in sorted(tdict.keys()):
            cnt = tdict[tr]
            print(f"    {tr}: {cnt} ({cnt/app_total*100:.2f}% of {app})")

    print("\nPer-application breakdown by transport (malicious):")
    for app in sorted(stats["app_trans_attack"].keys()):
        tdict = stats["app_trans_attack"][app]
        app_total = sum(tdict.values()) or 1
        print(f"  {app}:")
        for tr in sorted(tdict.keys()):
            cnt = tdict[tr]
            print(f"    {tr}: {cnt} ({cnt/app_total*100:.2f}% of malicious {app})")


def main():
    p = argparse.ArgumentParser(description="Task 1(a): Multi-PCAP + Labels → Aggregated + optional per-pair CSVs")
    p.add_argument("--pcap", action="append", required=True, help="PCAP file. Repeat for multiple.")
    p.add_argument("--labels", action="append", required=True, help="Labels CSV matching the preceding --pcap. Repeat for multiple.")
    p.add_argument("--outdir", default=".", help="Output directory (default: current dir)")
    p.add_argument("--outfile-base", default="ALL", help="Base name for aggregated output CSV (default: ALL)")
    p.add_argument("--per-pair-csv", action="store_true", help="Also write one CSV per (pcap, labels) pair.")
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args()

    if len(args.pcap) != len(args.labels):
        raise SystemExit("ERROR: You must provide the same number of --pcap and --labels arguments (paired in order).")

    # Validate inputs
    for pcap_path in args.pcap:
        if not os.path.exists(pcap_path):
            raise SystemExit(f"ERROR: PCAP not found: {pcap_path}")
    for lbl_path in args.labels:
        if not os.path.exists(lbl_path):
            raise SystemExit(f"ERROR: Labels file not found: {lbl_path}")

    aggregated = None

    # Process each (pcap, labels) pair in order
    for pcap_path, labels_path in zip(args.pcap, args.labels):
        if args.verbose:
            print(f"\n[PAIR] {pcap_path}  +  {labels_path}")
            print(f"Reading labels from {labels_path} ...")
        malicious_frames, n_rows = load_labels(labels_path)
        if args.verbose:
            print(f"Loaded labels: {n_rows} rows, malicious frames: {len(malicious_frames)}")

        if args.verbose:
            print(f"Analyzing {pcap_path} ...")
        stats = analyze_pcap(pcap_path, malicious_frames, verbose=args.verbose)

        if args.verbose:
            print(f"  -> In this pcap: total={stats['total_packets']}, "
                  f"malicious_in_pcap={stats['malicious_packets']}, normal={stats['normal_packets']}")

        # Optionally write a per-pair CSV
        if args.per_pair_csv:
            base = os.path.splitext(os.path.basename(pcap_path))[0]
            pair_csv = save_structured_csv(stats, args.outdir, outfile_base=base)
            print(f"Saved per-pair CSV → {pair_csv}")

        # Merge into the aggregated totals
        aggregated = merge_stats(aggregated, stats)

    # Print aggregated summary and write aggregated CSV
    print_summary(aggregated)
    out_csv = save_structured_csv(aggregated, args.outdir, args.outfile_base)
    print(f"\nSaved aggregated CSV  → {out_csv}")
    print("Done.")


if __name__ == "__main__":
    main()
