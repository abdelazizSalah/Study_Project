#!/usr/bin/env python3
"""
task1e.py — Modbus function-code distribution (multi-pcap, per-pair + aggregate)

python3 task1e.py \
  --pcap 'characterization_modbus_6RTU_with_operate (1).pcap' \
  --labels 'characterization_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'CnC_uploading_exe_modbus_6RTU_with_operate.pcap' \
  --labels 'CnC_uploading_exe_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'exploit_ms08_netapi_modbus_6RTU_with_operate.pcap' \
  --labels 'exploit_ms08_netapi_modbus_6RTU_with_operate_labeled (1).csv' \
  --pcap 'Modbus_polling_only_6RTU(2).pcap' \
  --labels 'Modbus_polling_only_6RTU_labeled.csv' \
  --pcap 'moving_two_files_modbus_6RTU.pcap' \
  --labels 'moving_two_files_modbus_6RTU_labeled.csv' \
  --pcap 'run1_12rtu_fixed.pcap' \
  --labels 'run1_12rtu_labeled.csv' \
  --pcap 'run11.pcap' \
  --labels 'run11_labeled.csv' \
  --pcap 'run1_3rtu_2s.pcap' \
  --labels 'run1_3rtu_2s_labeled (1).csv' \
  --pcap 'run1_6rtu(1).pcap' \
  --labels 'run1_6rtu_labeled.csv' \
  --pcap 'run8.pcap' \
  --labels 'run8_labeled.csv' \
  --pcap 'send_a_fake_command_modbus_6RTU_with_operate.pcap' \
  --labels 'send_a_fake_command_modbus_6RTU_with_operate_labeled (1).csv' \
  --outdir task1e_rez --outfile-base ALL --per-pair-csv --verbose
"""

import argparse
import os
import re
from collections import defaultdict

import pandas as pd
import pyshark

# Helpers

INFRA_LAYERS = {
    "ETH","ETHERNET","LLC","STP","VLAN","IP","IPV6","TCP","UDP",
    "ICMP","ICMPV6","ARP","NBNS","SSDP","MDNS","DATA","UNKNOWN"
}

MODBUS_NAMES = {
    1: "READ_COILS",
    2: "READ_DISCRETE_INPUTS",
    3: "READ_HOLDING_REGISTERS",
    4: "READ_INPUT_REGISTERS",
    5: "WRITE_SINGLE_COIL",
    6: "WRITE_SINGLE_REGISTER",
    7: "READ_EXCEPTION_STATUS",
    8: "DIAGNOSTICS",
    11: "GET_COMM_EVENT_COUNTER",
    12: "GET_COMM_EVENT_LOG",
    15: "WRITE_MULTIPLE_COILS",
    16: "WRITE_MULTIPLE_REGISTERS",
    17: "REPORT_SERVER_ID",
    20: "READ_FILE_RECORD",
    21: "WRITE_FILE_RECORD",
    22: "MASK_WRITE_REGISTER",
    23: "READ_WRITE_MULTIPLE_REGISTERS",
    24: "READ_FIFO_QUEUE",
    43: "ENCAPSULATED_INTERFACE_TRANSPORT",
}

def normalize_app(app: str) -> str:
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def load_labels(labels_path: str | None, verbose: bool=False) -> set[int]:
    """Return set of malicious frame numbers (empty set if no labels)."""
    if not labels_path:
        if verbose:
            print("  [labels] none provided → treating all packets as NORMAL (unless --A used).")
        return set()
    df = pd.read_csv(labels_path, engine="python", sep=None, header=None)
    if df.shape[1] != 2:
        raise SystemExit("ERROR: labels file must have exactly two columns: frame_number;label")
    df.columns = ["frame_number","label"]
    mal = set(df.loc[df["label"] == 1, "frame_number"].astype(int).tolist())
    if verbose:
        print(f"  [labels] loaded: {len(df)} rows, {len(mal)} malicious frames")
    return mal

# Robust function-code parsing from pyshark fields
FUNC_RE_HEX = re.compile(r'0x([0-9A-Fa-f]+)')
FUNC_RE_DEC = re.compile(r'\d+')

def parse_func_code(raw) -> int | None:
    """
    Accepts formats like:
      '0x03', '3', 'read_holding_registers (0x03)', '131' (exception bit set)
    Returns integer function code (0..127) with exception bit cleared.
    """
    if raw is None:
        return None
    s = str(raw)
    m = FUNC_RE_HEX.search(s)
    if m:
        val = int(m.group(1), 16)
    else:
        m2 = FUNC_RE_DEC.search(s)
        if not m2:
            return None
        val = int(m2.group(0))
    return val & 0x7F  # clear exception bit

def get_modbus_func(pkt):
    """Try multiple places for the function code."""
    # direct attributes
    try:
        if hasattr(pkt, "modbus") and hasattr(pkt.modbus, "func_code"):
            code = parse_func_code(pkt.modbus.func_code)
            if code is not None:
                return code
    except Exception:
        pass
    try:
        if hasattr(pkt, "mbtcp") and hasattr(pkt.mbtcp, "func_code"):
            code = parse_func_code(pkt.mbtcp.func_code)
            if code is not None:
                return code
    except Exception:
        pass
    # fallback: search in layer fields
    try:
        for lyr in getattr(pkt, "layers", []):
            if getattr(lyr, "layer_name", "").lower() in ("modbus","mbtcp"):
                for fname in getattr(lyr, "field_names", []):
                    if "func" in fname and "code" in fname:
                        code = parse_func_code(lyr.get_field_value(fname))
                        if code is not None:
                            return code
    except Exception:
        pass
    return None

# ------------------------ Aggregation / Output ------------------------

def build_records(rows, total_modbus):
    """
    rows: list of tuples (func_code, is_mal)
    returns: list of per-function dict records
    """
    if total_modbus == 0 or not rows:
        return []

    df = pd.DataFrame(rows, columns=["func_code","is_mal"])
    counts_all = df.groupby("func_code").size().to_dict()
    counts_mal = df.loc[df["is_mal"]].groupby("func_code").size().to_dict()

    records = []
    for code in sorted(counts_all.keys()):
        c_all = int(counts_all.get(code, 0))
        c_mal = int(counts_mal.get(code, 0))
        c_norm = c_all - c_mal
        frac_all = c_all / total_modbus
        frac_mal = c_mal / total_modbus
        frac_norm = c_norm / total_modbus
        name = "UNKNOWN" if code == -1 else MODBUS_NAMES.get(code, "UNKNOWN")
        records.append({
            "func_code": code if code >= 0 else "UNKNOWN",
            "func_name": name,
            "count_overall": c_all,
            "fraction_overall": frac_all,
            "count_malicious": c_mal,
            "fraction_malicious": frac_mal,
            "count_normal": c_norm,
            "fraction_normal": frac_norm,
        })
    return records

def write_outputs(records, total_modbus, out_struct, out_pretty, title="Task 1(e) Summary"):
    os.makedirs(os.path.dirname(out_struct), exist_ok=True)

    if not records or total_modbus == 0:
        # empty shells
        pd.DataFrame(columns=[
            "section","func_code","func_name","count_overall","fraction_overall",
            "count_malicious","fraction_malicious","count_normal","fraction_normal"
        ]).to_csv(out_struct, index=False)
        pd.DataFrame({"text": [
            f"=== {title} ===",
            "",
            "No MODBUS packets in dataset.",
            ""
        ]}).to_csv(out_pretty, index=False)
        print(f"[write] No MODBUS packets. Wrote empty summaries → {out_struct}, {out_pretty}")
        return

    # structured CSV
    structured_rows = [{"section": "modbus_function_distribution", **r} for r in records]
    pd.DataFrame(structured_rows, columns=[
        "section","func_code","func_name","count_overall","fraction_overall",
        "count_malicious","fraction_malicious","count_normal","fraction_normal"
    ]).to_csv(out_struct, index=False)

    # pretty text
    lines = []
    lines.append(f"=== {title} ===")
    lines.append("")
    lines.append(f"Total MODBUS packets: {total_modbus}")
    lines.append(f"Distinct function codes: {len(records)}")
    lines.append("")
    lines.append("Per-function distribution (fractions w.r.t ALL MODBUS packets):")
    for r in sorted(records, key=lambda x: (0 if x["func_code"] == "UNKNOWN" else 1, str(x["func_code"]))):
        code_disp = f"{r['func_code']} {r['func_name']}" if r["func_code"] != "UNKNOWN" else "UNKNOWN"
        lines.append(
            f"  {code_disp}: overall={r['count_overall']} ({r['fraction_overall']*100:.2f}%), "
            f"malicious={r['count_malicious']} ({r['fraction_malicious']*100:.2f}%), "
            f"normal={r['count_normal']} ({r['fraction_normal']*100:.2f}%)"
        )
    lines.append("")

    pd.DataFrame({"text": lines}).to_csv(out_pretty, index=False)
    print("\n".join(lines))
    print(f"[write] Saved CSV (structured) → {out_struct}")
    print(f"[write] Saved CSV (pretty)     → {out_pretty}")

#core

def process_one_pair(pcap_path, labels_path, A_flag, outdir, per_pair_csv, verbose=False):
    """
    Processes a single (pcap, labels/A) pair and optionally writes per-pair CSVs.
    Returns:
      rows: list of (func_code, is_mal) for this pair
      total_modbus: int
    """
    if not os.path.exists(pcap_path):
        raise SystemExit(f"PCAP not found: {pcap_path}")
    if labels_path and not os.path.exists(labels_path):
        raise SystemExit(f"Labels not found: {labels_path}")

    base = os.path.splitext(os.path.basename(pcap_path))[0]
    if verbose:
        print(f"\n[pcap] {pcap_path}")
    # Determine malicious frames source
    if labels_path:
        mal_frames = load_labels(labels_path, verbose=verbose)
        A = None
    else:
        mal_frames = set()
        A = A_flag
        if A is not None and verbose:
            print(f"  [A] --A={A} → all packets treated as {'malicious' if A==1 else 'normal'}.")

    cap = pyshark.FileCapture(pcap_path, keep_packets=False)
    rows = []
    total = 0
    total_modbus = 0

    for pkt in cap:
        total += 1
        if total % 1_000_000 == 0:
            print(f"[progress:{base}] processed {total:,} packets")

        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        if app != "MODBUS":
            continue

        total_modbus += 1

        # frame number
        try:
            frame_no = int(getattr(pkt, "number", total))
        except Exception:
            frame_no = total

        # malicious?
        if labels_path:
            is_mal = frame_no in mal_frames
        else:
            is_mal = (A == 1) if A is not None else False

        code = get_modbus_func(pkt)
        if code is None:
            code = -1  # unknown bucket

        rows.append((code, is_mal))

    cap.close()

    if verbose:
        print(f"  [done] all packets: {total:,}, MODBUS: {total_modbus:,}, rows: {len(rows):,}")

    # Per-pair CSVs
    if per_pair_csv:
        records = build_records(rows, total_modbus)
        out_struct = os.path.join(outdir, f"summary_{base}.csv")
        out_pretty = os.path.join(outdir, f"summary_pretty_{base}.csv")
        title = f"Task 1(e) Summary — {base}"
        write_outputs(records, total_modbus, out_struct, out_pretty, title=title)

    return rows, total_modbus

def main():
    ap = argparse.ArgumentParser(description="Task 1(e): Modbus function code distribution (multi-pcap)")
    # Repeatable inputs
    ap.add_argument("--pcap", action="append", required=True,
                    help="Input .pcap (repeatable; order matters)")
    ap.add_argument("--labels", action="append",
                    help="Labels CSV (frame_number;label). Repeat to match --pcap order. Optional.")
    ap.add_argument("--A", type=int, choices=[0,1], action="append",
                    help="Repeatable; per-pair quick flag (0=all normal, 1=all malicious) for corresponding --pcap when no labels provided.")
    # Output control
    ap.add_argument("--outdir", default="task1e", help="Output directory for CSVs")
    ap.add_argument("--outfile-base", default="ALL",
                    help="Base name for aggregate outputs (default: ALL)")
    ap.add_argument("--per-pair-csv", action="store_true",
                    help="Also write one CSV pair per (pcap, labels/A) input.")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    pcaps = args.pcap
    labels_list = args.labels or []
    A_list = args.A or []

    # Align lengths: labels_list and A_list are both optional; per pair, labels take precedence over A.
    # We’ll create a parallel list of (pcap, labels_or_None, A_or_None).
    pairs = []
    for i, p in enumerate(pcaps):
        lbl = labels_list[i] if i < len(labels_list) else None
        A = None if lbl else (A_list[i] if i < len(A_list) else None)
        pairs.append((p, lbl, A))

    if args.verbose:
        print(f"[inputs] {len(pairs)} pair(s)")
        for i, (p,lbl,A) in enumerate(pairs, 1):
            print(f"  {i:02d}. pcap={p} | labels={lbl or '-'} | A={A if A is not None else '-'}")

    os.makedirs(args.outdir, exist_ok=True)

    # Process each pair & collect for aggregate
    all_rows = []
    grand_total_modbus = 0

    for pcap_path, labels_path, A_flag in pairs:
        rows, total_modbus = process_one_pair(
            pcap_path, labels_path, A_flag,
            outdir=args.outdir,
            per_pair_csv=args.per_pair_csv,
            verbose=args.verbose
        )
        all_rows.extend(rows)
        grand_total_modbus += total_modbus

    # Aggregate across all inputs
    agg_records = build_records(all_rows, grand_total_modbus)
    agg_struct = os.path.join(args.outdir, f"summary_{args.outfile_base}.csv")
    agg_pretty = os.path.join(args.outdir, f"summary_pretty_{args.outfile_base}.csv")
    write_outputs(agg_records, grand_total_modbus, agg_struct, agg_pretty, title="Task 1(e) Summary — Aggregate")

if __name__ == "__main__":
    main()
