#!/usr/bin/env python3
"""
task1c.py — Task 1(c): Host-pair counts and inter-arrival stats with/without attacks

Usage:
  python3 task1b.py --pcap run8.pcap --labels run8_labeled.csv --A 0 --outdir task1b
  python3 task1b.py --pcap run8.pcap --A 0 --outdir task1b   # if dataset has no attacks
  python3 task1b.py --pcap some_capture.pcap --A 1 --outdir out  # treat whole pcap as malicious
"""

import argparse
import os
import numpy as np
import pandas as pd
import pyshark


# helpers

INFRA_LAYERS = {
    "ETH", "ETHERNET", "LLC", "STP", "VLAN", "IP", "IPV6",
    "TCP", "UDP", "ICMP", "ICMPV6", "ARP", "NBNS", "SSDP", "MDNS",
    "DATA", "UNKNOWN"
}

def normalize_app(app: str) -> str:
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def is_application_layer(app: str) -> bool:
    return bool(app) and app.upper() not in INFRA_LAYERS


#  packet collection

def collect_packets(pcap_path: str, mal_frames: set[int], verbose: bool=False) -> pd.DataFrame:
    """
    Returns DataFrame with columns:
      frame, ts, src, dst, app, trans, length, is_mal
    """
    cap = pyshark.FileCapture(pcap_path, keep_packets=False)
    rows = []
    total = 0
    for pkt in cap:
        total += 1
        if total % 1_000_000 == 0:
            print(f"Processed {total:,} packets...")

        # frame number
        try:
            frame = int(getattr(pkt, "number", total))
        except Exception:
            frame = total
        is_mal = frame in mal_frames

        # timestamp
        try:
            ts = float(pkt.sniff_time.timestamp())
        except Exception:
            try:
                ts = float(pkt.frame_info.time_epoch)
            except Exception:
                ts = None

        # endpoints
        src = dst = None
        if hasattr(pkt, "ip"):
            src, dst = pkt.ip.src, pkt.ip.dst
        elif hasattr(pkt, "ipv6"):
            src, dst = pkt.ipv6.src, pkt.ipv6.dst

        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        trans = getattr(pkt, "transport_layer", None) or "UNKNOWN"
        try:
            length = int(pkt.length)
        except Exception:
            length = None

        rows.append((frame, ts, src, dst, app, trans, length, is_mal))

    cap.close()
    df = pd.DataFrame(rows, columns=["frame","ts","src","dst","app","trans","length","is_mal"])
    if verbose:
        print(f"Collected packets: {len(df)}")
    return df


#  core computations

def compute_pairs_overview(df_app: pd.DataFrame) -> tuple[int, int]:
    """
    Count total unordered IP pairs (with any app-data packets),
    and how many of those pairs have >=1 malicious packet.
    """
    df = df_app.dropna(subset=["src","dst"]).copy()
    if df.empty:
        return 0, 0
    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    total_pairs = df["pair"].nunique()
    pair_mal = (
        df.groupby("pair")["is_mal"].any().sum()
    )
    return int(total_pairs), int(pair_mal)


def compute_interarrival_by_pair_app(df_app: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """
    Build inter-arrival deltas per (unordered pair, app) for:
      - NORMAL_strict: consecutive normal packets
      - MALICIOUS_strict: consecutive malicious packets
    Also aggregate per app (weighted by deltas count).
    """
    df = df_app.dropna(subset=["ts","src","dst"]).copy()
    if df.empty:
        empty_pair = pd.DataFrame(columns=["src","dst","app","subset","count","mean","std","median"])
        empty_app  = pd.DataFrame(columns=["app","subset","count","mean","std","median"])
        return {
            "pair_normal_strict": empty_pair,
            "pair_malicious_strict": empty_pair,
            "app_normal_strict": empty_app,
            "app_malicious_strict": empty_app,
        }

    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    df = df.sort_values(["pair","app","ts"])
    groups = df.groupby(["pair","app"], sort=False)

    rows_normal, rows_mal = [], []

    for (pair, app), g in groups:
        ts  = g["ts"].to_numpy(dtype=float)
        is_m = g["is_mal"].to_numpy()
        is_n = ~is_m
        if ts.size < 2:
            continue

        # NORMAL_strict: both packets are normal
        norm_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_n[i] and is_n[i+1]]
        if norm_d:
            norm_d = np.array(norm_d, dtype=float)
            rows_normal.append((
                pair[0], pair[1], app, "NORMAL_strict", len(norm_d),
                float(np.mean(norm_d)),
                float(np.std(norm_d, ddof=1)) if len(norm_d) > 1 else 0.0,
                float(np.median(norm_d)),
            ))

        # MALICIOUS_strict: both packets are malicious
        mal_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_m[i] and is_m[i+1]]
        if mal_d:
            mal_d = np.array(mal_d, dtype=float)
            rows_mal.append((
                pair[0], pair[1], app, "MALICIOUS_strict", len(mal_d),
                float(np.mean(mal_d)),
                float(np.std(mal_d, ddof=1)) if len(mal_d) > 1 else 0.0,
                float(np.median(mal_d)),
            ))

    cols = ["src","dst","app","subset","count","mean","std","median"]
    df_pair_normal = pd.DataFrame(rows_normal, columns=cols)
    df_pair_mal    = pd.DataFrame(rows_mal,    columns=cols)

    def agg_per_app(df_pair: pd.DataFrame, subset_name: str) -> pd.DataFrame:
        if df_pair.empty:
            return pd.DataFrame(columns=["app","subset","count","mean","std","median"])
        g = df_pair.groupby("app", as_index=False)
        rows = []
        for app, subdf in g:
            c_total = subdf["count"].sum()
            m_pool = (subdf["count"] * subdf["mean"]).sum() / c_total
            # pooled std approx
            if c_total > 1:
                var_terms = ((subdf["count"] - 1) * (subdf["std"]**2)).fillna(0.0) \
                            + subdf["count"] * ((subdf["mean"] - m_pool)**2)
                var_pool = var_terms.sum() / (c_total - 1)
                s_pool = float(np.sqrt(max(var_pool, 0.0)))
            else:
                s_pool = 0.0
            med_pool = float((subdf["count"] * subdf["median"]).sum() / c_total)
            rows.append((app, subset_name, int(c_total), float(m_pool), float(s_pool), float(med_pool)))
        return pd.DataFrame(rows, columns=["app","subset","count","mean","std","median"])

    app_normal = agg_per_app(df_pair_normal, "NORMAL_strict")
    app_mal    = agg_per_app(df_pair_mal,    "MALICIOUS_strict")

    return {
        "pair_normal_strict": df_pair_normal,
        "pair_malicious_strict": df_pair_mal,
        "app_normal_strict": app_normal,
        "app_malicious_strict": app_mal,
    }


#  saving & printing

def save_structured_csv(pair_counts: dict, interstats: dict, outdir: str, pcap_path: str) -> str:
    """
    Structured CSV with sections:
      - pairs_overview
      - interarrival_pair_normal_strict
      - interarrival_pair_malicious_strict
      - interarrival_app_normal_strict
      - interarrival_app_malicious_strict
    """
    os.makedirs(outdir, exist_ok=True)
    base = os.path.splitext(os.path.basename(pcap_path))[0]
    csv_path = os.path.join(outdir, f"summary_{base}.csv")

    rows = []

    # pairs overview
    rows.append({
        "section": "pairs_overview",
        "metric": "total_pairs",
        "value": pair_counts["total_pairs"]
    })
    rows.append({
        "section": "pairs_overview",
        "metric": "pairs_with_attacks",
        "value": pair_counts["pairs_with_attacks"]
    })
    rows.append({
        "section": "pairs_overview",
        "metric": "pairs_without_attacks",
        "value": pair_counts["total_pairs"] - pair_counts["pairs_with_attacks"]
    })

    # pair-level inter-arrival
    for section_key in ["pair_normal_strict", "pair_malicious_strict"]:
        dfp = interstats[section_key]
        if not dfp.empty:
            for _, r in dfp.iterrows():
                rows.append({
                    "section": section_key,
                    "app_protocol": r["app"],
                    "src_ip": r["src"],
                    "dst_ip": r["dst"],
                    "subset": r["subset"],
                    "count": int(r["count"]),
                    "mean": float(r["mean"]),
                    "std": float(r["std"]),
                    "median": float(r["median"]),
                })

    # app-level aggregates
    for section_key in ["app_normal_strict", "app_malicious_strict"]:
        dfa = interstats[section_key]
        if not dfa.empty:
            for _, r in dfa.iterrows():
                rows.append({
                    "section": section_key,
                    "app_protocol": r["app"],
                    "src_ip": "",
                    "dst_ip": "",
                    "subset": r["subset"],
                    "count": int(r["count"]),
                    "mean": float(r["mean"]) if pd.notna(r["mean"]) else "",
                    "std": float(r["std"]) if pd.notna(r["std"]) else "",
                    "median": float(r["median"]) if pd.notna(r["median"]) else "",
                })

    # save
    pd.DataFrame(rows, columns=[
        "section","metric","value","app_protocol","src_ip","dst_ip","subset","count","mean","std","median"
    ]).to_csv(csv_path, index=False)

    return csv_path


def save_pretty_csv(pair_counts: dict, interstats: dict, outdir: str, pcap_path: str) -> str:
    """
    Pretty CSV mirroring console lines (one text line per row).
    """
    os.makedirs(outdir, exist_ok=True)
    base = os.path.splitext(os.path.basename(pcap_path))[0]
    out_path = os.path.join(outdir, f"summary_pretty_{base}.csv")

    lines = []
    lines.append("=== Task 1(c) Summary ===")
    lines.append("")
    lines.append(f"Total unordered host pairs (with app data): {pair_counts['total_pairs']}")
    lines.append(f"Pairs with attacks: {pair_counts['pairs_with_attacks']}")
    lines.append(f"Pairs without attacks: {pair_counts['total_pairs'] - pair_counts['pairs_with_attacks']}")
    lines.append("")

    # NORMAL_strict pairs
    lines.append("Inter-arrival (seconds) — same unordered host pair AND same app — WITHOUT attacks (NORMAL_strict):")
    dfpn = interstats["pair_normal_strict"]
    if dfpn.empty:
        lines.append("  (none)")
    else:
        for _, r in dfpn.sort_values(["app","src","dst"]).iterrows():
            lines.append(
                f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                f"mean={r['mean']:.6f}s, std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s"
            )
    lines.append("")

    # MALICIOUS_strict pairs
    lines.append("Inter-arrival (seconds) — same unordered host pair AND same app — WITH attacks (MALICIOUS_strict):")
    dfpm = interstats["pair_malicious_strict"]
    if dfpm.empty:
        lines.append("  (none)")
    else:
        for _, r in dfpm.sort_values(["app","src","dst"]).iterrows():
            lines.append(
                f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                f"mean={r['mean']:.6f}s, std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s"
            )
    lines.append("")

    # app aggregates
    dfa_n = interstats["app_normal_strict"]
    dfa_m = interstats["app_malicious_strict"]

    lines.append("Aggregated per application — WITHOUT attacks (NORMAL_strict):")
    if dfa_n.empty:
        lines.append("  (none)")
    else:
        for _, r in dfa_n.sort_values(["app"]).iterrows():
            lines.append(
                f"  {r['app']}: deltas={int(r['count'])}, mean={r['mean']:.6f}s, "
                f"std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s"
            )
    lines.append("")

    lines.append("Aggregated per application — WITH attacks (MALICIOUS_strict):")
    if dfa_m.empty:
        lines.append("  (none)")
    else:
        for _, r in dfa_m.sort_values(["app"]).iterrows():
            lines.append(
                f"  {r['app']}: deltas={int(r['count'])}, mean={r['mean']:.6f}s, "
                f"std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s"
            )
    lines.append("")

    pd.DataFrame({"text": lines}).to_csv(out_path, index=False)
    return out_path


def print_summary(pair_counts: dict, interstats: dict) -> None:
    print("\n=== Task 1(c) Summary ===\n")
    print(f"Total unordered host pairs (with app data): {pair_counts['total_pairs']}")
    print(f"Pairs with attacks: {pair_counts['pairs_with_attacks']}")
    print(f"Pairs without attacks: {pair_counts['total_pairs'] - pair_counts['pairs_with_attacks']}\n")

    def print_pairs_block(df_pair: pd.DataFrame, title: str):
        print(title)
        if df_pair.empty:
            print("  (none)\n")
            return
        for _, r in df_pair.sort_values(["app","src","dst"]).iterrows():
            print(f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, "
                  f"mean={r['mean']:.6f}s, std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s")
        print("")

    print_pairs_block(interstats["pair_normal_strict"],
        "Inter-arrival (seconds) — same unordered host pair AND same app — WITHOUT attacks (NORMAL_strict):")
    print_pairs_block(interstats["pair_malicious_strict"],
        "Inter-arrival (seconds) — same unordered host pair AND same app — WITH attacks (MALICIOUS_strict):")

    def print_app_block(dfa: pd.DataFrame, title: str):
        print(title)
        if dfa.empty:
            print("  (none)\n")
            return
        for _, r in dfa.sort_values(["app"]).iterrows():
            print(f"  {r['app']}: deltas={int(r['count'])}, mean={r['mean']:.6f}s, "
                  f"std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s")
        print("")

    print_app_block(interstats["app_normal_strict"],   "Aggregated per application — WITHOUT attacks (NORMAL_strict):")
    print_app_block(interstats["app_malicious_strict"],"Aggregated per application — WITH attacks (MALICIOUS_strict):")



def main():
    ap = argparse.ArgumentParser(description="Task 1(c): Pair counts and inter-arrival with/without attacks")
    ap.add_argument("--pcap", required=True, help="Input .pcap")
    ap.add_argument("--A", required=True, type=int, choices=[0, 1],
                    help="1 = treat ALL packets as malicious; 0 = treat ALL packets as normal")
    ap.add_argument("--outdir", default=".", help="Output directory")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.pcap):
        raise SystemExit(f"PCAP not found: {args.pcap}")

    # No labels file; start with empty set (collect as normal), then override below
    mal_frames = set()
    df = collect_packets(args.pcap, mal_frames, verbose=args.verbose)

    # Override labels according to --A
    if args.A == 1:
        df["is_mal"] = True
    else:
        df["is_mal"] = False

    # Only packets with application data
    df_app = df[df["app"].apply(is_application_layer)].copy()

    # Pair counts
    total_pairs, pairs_with_attacks = compute_pairs_overview(df_app)
    pair_counts = {
        "total_pairs": total_pairs,
        "pairs_with_attacks": pairs_with_attacks,
    }

    # Inter-arrival stats
    interstats = compute_interarrival_by_pair_app(df_app)

    # Console + CSVs
    print_summary(pair_counts, interstats)
    out1 = save_structured_csv(pair_counts, interstats, args.outdir, args.pcap)
    out2 = save_pretty_csv(pair_counts, interstats, args.outdir, args.pcap)
    print(f"Saved CSV (structured) → {out1}")
    print(f"Saved CSV (pretty)     → {out2}")
    print("Done.")

if __name__ == "__main__":
    main()

