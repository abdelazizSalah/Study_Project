#!/usr/bin/env python3
"""
task1e.py — Modbus function-code distribution (overall + under attack)

Usage:
  python3 task1b.py --pcap run8.pcap --labels run8_labeled.csv --A 0 --outdir task1b
  python3 task1b.py --pcap run8.pcap --A 0 --outdir task1b   # if dataset has no attacks
  python3 task1b.py --pcap some_capture.pcap --A 1 --outdir out  # treat whole pcap as malicious
"""

import argparse
import os
import re
from collections import defaultdict

import numpy as np
import pandas as pd
import pyshark


# Helpers

INFRA_LAYERS = {
    "ETH","ETHERNET","LLC","STP","VLAN","IP","IPV6","TCP","UDP",
    "ICMP","ICMPV6","ARP","NBNS","SSDP","MDNS","DATA","UNKNOWN"
}

MODBUS_NAMES = {
    1: "READ_COILS",
    2: "READ_DISCRETE_INPUTS",
    3: "READ_HOLDING_REGISTERS",
    4: "READ_INPUT_REGISTERS",
    5: "WRITE_SINGLE_COIL",
    6: "WRITE_SINGLE_REGISTER",
    7: "READ_EXCEPTION_STATUS",
    8: "DIAGNOSTICS",
    11: "GET_COMM_EVENT_COUNTER",
    12: "GET_COMM_EVENT_LOG",
    15: "WRITE_MULTIPLE_COILS",
    16: "WRITE_MULTIPLE_REGISTERS",
    17: "REPORT_SERVER_ID",
    20: "READ_FILE_RECORD",
    21: "WRITE_FILE_RECORD",
    22: "MASK_WRITE_REGISTER",
    23: "READ_WRITE_MULTIPLE_REGISTERS",
    24: "READ_FIFO_QUEUE",
    43: "ENCAPSULATED_INTERFACE_TRANSPORT",
}

def normalize_app(app: str) -> str:
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def is_application_layer(app: str) -> bool:
    return bool(app) and app.upper() not in INFRA_LAYERS

# Robust function-code parsing from pyshark fields (works with various Wireshark builds)
FUNC_RE_HEX = re.compile(r'0x([0-9A-Fa-f]+)')
FUNC_RE_DEC = re.compile(r'\d+')

def parse_func_code(raw) -> int | None:
    """
    Accepts formats like:
      '0x03', '3', 'read_holding_registers (0x03)', '131' (exception bit set)
    Returns integer function code (0..127) with exception bit cleared.
    """
    if raw is None:
        return None
    s = str(raw)
    m = FUNC_RE_HEX.search(s)
    if m:
        val = int(m.group(1), 16)
    else:
        m2 = FUNC_RE_DEC.search(s)
        if not m2:
            return None
        val = int(m2.group(0))
    # clear exception bit (0x80) to group requests and exception responses together
    return val & 0x7F

def get_modbus_func(pkt):
    """
    Try multiple places for the function code:
    - pkt.modbus.func_code
    - pkt.mbtcp.func_code
    - fall back scanning layer fields if needed
    """
    # direct attributes
    try:
        if hasattr(pkt, "modbus") and hasattr(pkt.modbus, "func_code"):
            code = parse_func_code(pkt.modbus.func_code)
            if code is not None:
                return code
    except Exception:
        pass
    try:
        if hasattr(pkt, "mbtcp") and hasattr(pkt.mbtcp, "func_code"):
            code = parse_func_code(pkt.mbtcp.func_code)
            if code is not None:
                return code
    except Exception:
        pass
    # fallback: search in layer fields
    try:
        for lyr in getattr(pkt, "layers", []):
            if getattr(lyr, "layer_name", "").lower() in ("modbus","mbtcp"):
                for fname in getattr(lyr, "field_names", []):
                    if "func" in fname and "code" in fname:
                        code = parse_func_code(lyr.get_field_value(fname))
                        if code is not None:
                            return code
    except Exception:
        pass
    return None

def func_label(code: int) -> str:
    name = MODBUS_NAMES.get(code, "UNKNOWN")
    return f"{code} {name}"


def main():
    ap = argparse.ArgumentParser(description="Task 1(e): Modbus function code distribution")
    ap.add_argument("--pcap", required=True, help="Input .pcap")
    ap.add_argument("--A", required=True, type=int, choices=[0, 1],
                    help="1 = treat ALL packets as malicious; 0 = treat ALL packets as normal")
    ap.add_argument("--outdir", default="task1e", help="Output directory for CSVs")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.pcap):
        raise SystemExit(f"PCAP not found: {args.pcap}")

    force_malicious = (args.A == 1)

    cap = pyshark.FileCapture(args.pcap, keep_packets=False)
    rows = []
    total = 0
    total_modbus = 0
    for pkt in cap:
        total += 1
        if total % 1_000_000 == 0:
            print(f"Processed {total:,} packets...", flush=True)

        # app filter
        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        if app != "MODBUS":
            continue

        total_modbus += 1

        # frame number (kept but not used for labels anymore)
        try:
            frame_no = int(getattr(pkt, "number", total))
        except Exception:
            frame_no = total
        is_mal = force_malicious

        code = get_modbus_func(pkt)
        if code is None:
            # still include as "unknown" bucket
            code = -1  # special bucket for missing codes

        rows.append((code, is_mal))
    cap.close()

    if args.verbose:
        print(f"All packets: {total}, MODBUS packets: {total_modbus}, rows collected: {len(rows)}")

    # Aggregate
    df = pd.DataFrame(rows, columns=["func_code","is_mal"])
    # If no Modbus packets at all, write empty but valid outputs
    base = os.path.splitext(os.path.basename(args.pcap))[0]
    os.makedirs(args.outdir, exist_ok=True)
    out_struct = os.path.join(args.outdir, f"summary_{base}.csv")
    out_pretty = os.path.join(args.outdir, f"summary_pretty_{base}.csv")

    if df.empty or total_modbus == 0:
        # Save empty shells
        pd.DataFrame(columns=[
            "section","func_code","func_name","count_overall","fraction_overall",
            "count_malicious","fraction_malicious","count_normal","fraction_normal"
        ]).to_csv(out_struct, index=False)
        pd.DataFrame({"text": [
            "=== Task 1(e) Summary ===",
            "",
            "No MODBUS packets in dataset.",
            ""
        ]}).to_csv(out_pretty, index=False)
        print("No MODBUS packets in dataset. Wrote empty summaries.")
        print(f"Saved CSV (structured) → {out_struct}")
        print(f"Saved CSV (pretty)     → {out_pretty}")
        print("Done.")
        return

    # counts overall & malicious
    counts_all = df.groupby("func_code").size().to_dict()
    counts_mal = df.loc[df["is_mal"]].groupby("func_code").size().to_dict()

    # Build table per function code
    records = []
    for code in sorted(counts_all.keys()):
        c_all = int(counts_all.get(code, 0))
        c_mal = int(counts_mal.get(code, 0))
        c_norm = c_all - c_mal
        frac_all = c_all / total_modbus
        frac_mal = c_mal / total_modbus  # fraction of *all Modbus* that are malicious for this code
        frac_norm = c_norm / total_modbus
        name = "UNKNOWN" if code == -1 else MODBUS_NAMES.get(code, "UNKNOWN")
        records.append({
            "func_code": code if code >= 0 else "UNKNOWN",
            "func_name": name,
            "count_overall": c_all,
            "fraction_overall": frac_all,
            "count_malicious": c_mal,
            "fraction_malicious": frac_mal,
            "count_normal": c_norm,
            "fraction_normal": frac_norm,
        })

    #  Structured CSV
    structured_rows = []
    for r in records:
        structured_rows.append({
            "section": "modbus_function_distribution",
            **r
        })

    pd.DataFrame(structured_rows, columns=[
        "section","func_code","func_name","count_overall","fraction_overall",
        "count_malicious","fraction_malicious","count_normal","fraction_normal"
    ]).to_csv(out_struct, index=False)

    #  Pretty CSV + console
    lines = []
    lines.append("=== Task 1(e) Summary ===")
    lines.append("")
    lines.append(f"Total MODBUS packets: {total_modbus}")
    lines.append(f"Distinct function codes: {sum(1 for _ in records)}")
    lines.append("")
    lines.append("Per-function distribution (fractions w.r.t ALL MODBUS packets):")
    for r in sorted(records, key=lambda x: (0 if x["func_code"] == "UNKNOWN" else 1, str(x["func_code"]))):
        code_disp = f"{r['func_code']} {r['func_name']}" if r["func_code"] != "UNKNOWN" else "UNKNOWN"
        lines.append(
            f"  {code_disp}: overall={r['count_overall']} ({r['fraction_overall']*100:.2f}%), "
            f"malicious={r['count_malicious']} ({r['fraction_malicious']*100:.2f}%), "
            f"normal={r['count_normal']} ({r['fraction_normal']*100:.2f}%)"
        )
    lines.append("")

    # Save pretty CSV
    pd.DataFrame({"text": lines}).to_csv(out_pretty, index=False)

    # Print to console too
    print("\n".join(lines))
    print(f"Saved CSV (structured) → {out_struct}")
    print(f"Saved CSV (pretty)     → {out_pretty}")
    print("Done.")


if __name__ == "__main__":
    main()
