#!/usr/bin/env python3
"""
task1a_flag.py — Task 1(a) modified: Dataset Characterization with single attack flag + progress counter


Usage:
  python3 task1a.py --pcap run8.pcap --labels run8_labeled.csv --A 0 --outdir task1b
  python3 task1a.py --pcap run8.pcap --A 0 --outdir task1b   # if dataset has no attacks
  python3 task1a.py --pcap some_capture.pcap --A 1 --outdir out  # treat whole pcap as malicious
"""

import argparse
import os
from collections import Counter, defaultdict
import pandas as pd
import pyshark


# Analyze pcap with attack flag

def analyze_pcap(pcap_path, attack_flag):
    # Disable name resolution for speed
    cap = pyshark.FileCapture(
        pcap_path,
        keep_packets=False,
        custom_parameters=["-n"]
    )

    total_packets = 0
    app_counter = Counter()
    trans_counter = Counter()
    app_trans = defaultdict(lambda: Counter())

    print("[info] Starting packet processing...")
    for pkt in cap:
        total_packets += 1

        # --- Progress heartbeat ---
        if total_packets % 1_000_000 == 0:
            print(f"[progress] Processed {total_packets:,} packets...", flush=True)

        # Extract fields safely
        app = getattr(pkt, "highest_layer", "UNKNOWN") or "UNKNOWN"
        trans = getattr(pkt, "transport_layer", "UNKNOWN") or "UNKNOWN"
        app_counter[app] += 1
        trans_counter[trans] += 1
        app_trans[app][trans] += 1

    cap.close()

    malicious_packets = total_packets if attack_flag == 1 else 0
    normal_packets = 0 if attack_flag == 1 else total_packets

    print(f"[done] Finished reading {total_packets:,} packets.\n")

    return {
        "total_packets": total_packets,
        "malicious_packets": malicious_packets,
        "normal_packets": normal_packets,
        "app_counter": app_counter,
        "trans_counter": trans_counter,
        "app_trans": app_trans,
        "attack_flag": attack_flag,
    }



# Save structured CSV

def save_structured_csv(stats, outdir, pcap_path):
    os.makedirs(outdir, exist_ok=True)
    base = os.path.splitext(os.path.basename(pcap_path))[0]
    csv_path = os.path.join(outdir, f"summary_{base}.csv")

    rows = []
    total = stats["total_packets"] or 1

    # summary
    rows += [
        {"section": "summary", "app_protocol": "total_packets", "transport_protocol": "",
         "count": stats["total_packets"], "fraction_of_total": 1.0, "fraction_within_app": ""},
        {"section": "summary", "app_protocol": "malicious_packets", "transport_protocol": "",
         "count": stats["malicious_packets"], "fraction_of_total": stats["malicious_packets"]/total, "fraction_within_app": ""},
        {"section": "summary", "app_protocol": "normal_packets", "transport_protocol": "",
         "count": stats["normal_packets"], "fraction_of_total": stats["normal_packets"]/total, "fraction_within_app": ""}
    ]

    # app / transport counters
    for section, counter in (("app_overall", stats["app_counter"]),
                             ("transport_overall", stats["trans_counter"])):

        for key, val in counter.items():
            rows.append({
                "section": section,
                "app_protocol": key if "app" in section else "",
                "transport_protocol": key if "transport" in section else "",
                "count": int(val),
                "fraction_of_total": val / total,
                "fraction_within_app": ""
            })

    # app_transport (overall)
    for app, tdict in stats["app_trans"].items():
        app_total = sum(tdict.values()) or 1
        for tr, cnt in tdict.items():
            rows.append({
                "section": "app_transport_overall",
                "app_protocol": app,
                "transport_protocol": tr,
                "count": int(cnt),
                "fraction_of_total": cnt / total,
                "fraction_within_app": cnt / app_total
            })

    pd.DataFrame(rows).to_csv(csv_path, index=False)
    return csv_path



# Print summary

def print_summary(stats):
    print("\n=== Task 1(a) Summary (Attack flag mode) ===")
    print(f"Total packets: {stats['total_packets']}")
    print(f"Attack flag: {'ATTACKED' if stats['attack_flag'] == 1 else 'NORMAL'}")
    print(f"Malicious packets: {stats['malicious_packets']}")
    print(f"Normal packets: {stats['normal_packets']}\n")

    total = stats["total_packets"] or 1

    print("Application-layer protocols:")
    for k, v in stats["app_counter"].items():
        print(f"  {k}: {v} ({v/total*100:.2f}%)")

    print("\nTransport-layer protocols:")
    for k, v in stats["trans_counter"].items():
        print(f"  {k}: {v} ({v/total*100:.2f}%)")

    print("\nPer-application breakdown by transport:")
    for app, tdict in stats["app_trans"].items():
        app_total = sum(tdict.values()) or 1
        print(f"  {app}:")
        for tr, cnt in tdict.items():
            print(f"    {tr}: {cnt} ({cnt/app_total*100:.2f}% of {app})")



def main():
    p = argparse.ArgumentParser(description="Task 1(a) with attack flag (no labels file).")
    p.add_argument("--pcap", required=True)
    p.add_argument("--A", type=int, choices=[0, 1], required=True,
                   help="Attack flag: 1 = whole PCAP is attacked, 0 = no attack")
    p.add_argument("--outdir", default=".")
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args()

    if not os.path.exists(args.pcap):
        raise SystemExit(f"ERROR: PCAP not found: {args.pcap}")

    if args.verbose:
        print(f"Reading PCAP: {args.pcap}")
        print(f"Attack flag set to: {args.A}")

    stats = analyze_pcap(args.pcap, args.A)

    print_summary(stats)

    out_csv = save_structured_csv(stats, args.outdir, args.pcap)
    print(f"\nSaved CSV  → {out_csv}")
    print("Done.")


if __name__ == "__main__":
    main()

