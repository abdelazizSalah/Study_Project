#!/usr/bin/env python3
"""
task1d.py — CCDF plots for header & payload lengths per app protocol (NORMAL vs MALICIOUS)
-----------------------------------------------------------------------------------------
Usage:
  python3 task1d.py --pcap run8.pcap --labels run8_labeled.csv --A 0 --outdir task1b
  python3 task1d.py --pcap run8.pcap --A 0 --outdir task1b   # if dataset has no attacks
  python3 task1d.py --pcap some_capture.pcap --A 1 --outdir out  # treat whole pcap as malicious
"""

import argparse
import os
import re
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
import pyshark


INFRA_LAYERS = {
    "ETH", "ETHERNET", "LLC", "STP", "VLAN", "IP", "IPV6", "TCP", "UDP",
    "ICMP", "ICMPV6", "ARP", "NBNS", "SSDP", "MDNS", "DATA", "UNKNOWN"
}


def normalize_app(app: str) -> str:
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u


def is_application_layer(app: str) -> bool:
    return bool(app) and app.upper() not in INFRA_LAYERS


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name.strip())


def estimate_header_payload_lengths(pkt):
    try:
        total_len = int(pkt.length)
    except Exception:
        return None, None

    payload_len = None
    try:
        if hasattr(pkt, "tcp") and hasattr(pkt.tcp, "len"):
            payload_len = int(pkt.tcp.len)
    except Exception:
        pass
    try:
        if payload_len is None and hasattr(pkt, "udp"):
            if hasattr(pkt.udp, "length"):
                payload_len = max(int(pkt.udp.length) - 8, 0)
    except Exception:
        pass

    if payload_len is None:
        eth_hdr = 14
        if hasattr(pkt, "vlan"):
            eth_hdr += 4
        ip_hdr = 0
        if hasattr(pkt, "ip") and hasattr(pkt.ip, "hdr_len"):
            ip_hdr = int(pkt.ip.hdr_len)
        elif hasattr(pkt, "ipv6"):
            ip_hdr = 40
        trans_hdr = 0
        if hasattr(pkt, "tcp") and hasattr(pkt.tcp, "hdr_len"):
            trans_hdr = int(pkt.tcp.hdr_len)
        elif hasattr(pkt, "udp"):
            trans_hdr = 8
        payload_len = max(total_len - (eth_hdr + ip_hdr + trans_hdr), 0)

    header_len = max(total_len - payload_len, 0)
    return header_len, payload_len


def ccdf(values):
    if not values:
        return np.array([]), np.array([])
    x = np.sort(np.asarray(values, dtype=float))
    n = x.size
    ranks = np.arange(1, n + 1, dtype=float)
    y = (n - ranks + 1) / n
    return x, y


def plot_ccdf_per_type(out_path, app, hdr_values, pay_values, subset):
    import matplotlib
    plt.figure(figsize=(8, 6), dpi=110)
    xh, yh = ccdf(hdr_values)
    xp, yp = ccdf(pay_values)

    if xh.size:
        plt.plot(xh, yh, label="Header Length")
    if xp.size:
        plt.plot(xp, yp, label="Payload Length")

    plt.xlabel("Bytes")
    plt.ylabel("CCDF (P(X ≥ x))")
    plt.title(f"{app} — {subset} Packets")
    plt.grid(True, linestyle="--", alpha=0.35)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


def main():
    ap = argparse.ArgumentParser(description="Task 1(d): CCDF plots per app (linear scale)")
    ap.add_argument("--pcap", required=True)
    ap.add_argument("--A", required=True, type=int, choices=[0, 1],
                    help="1 = treat ALL packets as malicious; 0 = treat ALL packets as normal")
    ap.add_argument("--outdir", default="task1d")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    base = os.path.splitext(os.path.basename(args.pcap))[0]
    out_subdir = os.path.join(args.outdir, f"{base}_ccdf_plots")
    os.makedirs(out_subdir, exist_ok=True)

    force_malicious = (args.A == 1)
    if args.verbose:
        print(f"Mode: {'MALICIOUS' if force_malicious else 'NORMAL'} (from --A {args.A})")

    hdr_norm, pay_norm = defaultdict(list), defaultdict(list)
    hdr_mal, pay_mal = defaultdict(list), defaultdict(list)

    cap = pyshark.FileCapture(args.pcap, keep_packets=False)
    total = 0
    for pkt in cap:
        total += 1
        if total % 1_000_000 == 0:
            print(f"Processed {total:,} packets...")

        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        if not is_application_layer(app):
            continue

        hlen, plen = estimate_header_payload_lengths(pkt)
        if hlen is None or plen is None:
            continue

        if force_malicious:
            hdr_mal[app].append(hlen)
            pay_mal[app].append(plen)
        else:
            hdr_norm[app].append(hlen)
            pay_norm[app].append(plen)
    cap.close()

    apps = sorted(set(hdr_norm.keys()) | set(hdr_mal.keys()) | set(pay_norm.keys()) | set(pay_mal.keys()))
    if not apps:
        print("No application-layer packets found.")
        return

    print(f"\n=== Task 1(d) CCDF Plots (Linear) for {base} ===")
    for app in apps:
        if not force_malicious:
            norm_hdr, norm_pay = hdr_norm.get(app, []), pay_norm.get(app, [])
            if norm_hdr or norm_pay:
                out_norm = os.path.join(out_subdir, f"{safe_name(app)}_ccdf_normal.png")
                plot_ccdf_per_type(out_norm, app, norm_hdr, norm_pay, "NORMAL")
                print(f"  NORMAL → {out_norm}")

        if force_malicious:
            mal_hdr, mal_pay = hdr_mal.get(app, []), pay_mal.get(app, [])
            if mal_hdr or mal_pay:
                out_mal = os.path.join(out_subdir, f"{safe_name(app)}_ccdf_malicious.png")
                plot_ccdf_per_type(out_mal, app, mal_hdr, mal_pay, "MALICIOUS")
                print(f"  MALICIOUS → {out_mal}")
    print("Done.\n")


if __name__ == "__main__":
    main()
