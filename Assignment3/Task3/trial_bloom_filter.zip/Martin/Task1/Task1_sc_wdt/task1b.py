#!/usr/bin/env python3
"""
task1b.py — Task 1(b): Length & Inter-Arrival stats with/without attacks

Usage:
  python3 task1b.py --pcap run8.pcap --labels run8_labeled.csv --A 0 --outdir task1b
  python3 task1b.py --pcap run8.pcap --A 0 --outdir task1b   # if dataset has no attacks
  python3 task1b.py --pcap some_capture.pcap --A 1 --outdir out  # treat whole pcap as malicious
"""

import argparse
import os
import numpy as np
import pandas as pd
import pyshark


# Helpers


INFRA_LAYERS = {
    "ETH", "ETHERNET", "LLC", "STP", "VLAN", "IP", "IPV6", "TCP", "UDP",
    "ICMP", "ICMPV6", "ARP", "NBNS", "SSDP", "MDNS", "DATA", "UNKNOWN"
}

def normalize_app(app):
    if not app:
        return "UNKNOWN"
    u = app.upper()
    if u in ("MODBUS/TCP", "MBTCP"):
        return "MODBUS"
    return u

def is_application_layer(app):
    if not app:
        return False
    return app.upper() not in INFRA_LAYERS



# Load labels

def load_labels(labels_path, verbose=False):
    if not labels_path:
        if verbose:
            print("No labels provided → treating per-frame labels as empty (use --A to mark whole PCAP).")
        return set()
    df = pd.read_csv(labels_path, engine="python", sep=None, header=None)
    if df.shape[1] != 2:
        raise SystemExit("ERROR: labels CSV must have 2 columns: frame_number;label")
    df.columns = ["frame_number", "label"]
    mal = set(df.loc[df["label"] == 1, "frame_number"].astype(int).tolist())
    if verbose:
        print(f"Loaded labels: {len(df)} rows, {len(mal)} malicious")
    return mal



# Capture packets

def collect_packets(pcap_path, mal_frames, all_malicious=False, verbose=False):
    """
    Collects packets into a DataFrame.
    all_malicious: if True -> treat every packet as malicious (ignores mal_frames)
    """
    cap = pyshark.FileCapture(pcap_path, keep_packets=False, custom_parameters=["-n"])
    rows = []
    total = 0
    print("[info] Starting packet capture (this may take a while)...")
    for pkt in cap:
        total += 1
        try:
            frame = int(getattr(pkt, "number", 0))
        except Exception:
            frame = 0
        # global flag overrides per-frame labels
        is_mal = all_malicious or (frame in mal_frames)
        try:
            ts = float(pkt.sniff_time.timestamp())
        except Exception:
            ts = None
        src = dst = None
        if hasattr(pkt, "ip"):
            src, dst = pkt.ip.src, pkt.ip.dst
        elif hasattr(pkt, "ipv6"):
            src, dst = pkt.ipv6.src, pkt.ipv6.dst
        app = normalize_app(getattr(pkt, "highest_layer", "UNKNOWN"))
        trans = getattr(pkt, "transport_layer", None) or "UNKNOWN"
        try:
            length = int(pkt.length)
        except Exception:
            length = None
        rows.append((frame, ts, src, dst, app, trans, length, is_mal))

        # Progress counter every 1 million packets
        if total % 1_000_000 == 0:
            print(f"[progress] Processed {total:,} packets...", flush=True)

    cap.close()
    print(f"[done] Finished reading {total:,} packets.")
    df = pd.DataFrame(rows, columns=["frame","ts","src","dst","app","trans","length","is_mal"])
    if verbose:
        print(f"Captured packets: {len(df)}")
    return df



# Length statistics

def compute_length_stats(df):
    g_all = df.groupby("app")["length"]
    all_ = g_all.agg(count="count", mean="mean", std="std", median="median").reset_index()
    all_.insert(1, "subset", "ALL")

    df_norm = df[~df["is_mal"]]
    df_mal  = df[df["is_mal"]]

    norm = pd.DataFrame()
    mal  = pd.DataFrame()

    if not df_norm.empty:
        g = df_norm.groupby("app")["length"]
        norm = g.agg(count="count", mean="mean", std="std", median="median").reset_index()
        norm.insert(1, "subset", "NORMAL")

    if not df_mal.empty:
        g = df_mal.groupby("app")["length"]
        mal = g.agg(count="count", mean="mean", std="std", median="median").reset_index()
        mal.insert(1, "subset", "MALICIOUS")

    return all_, norm, mal



# Inter-arrival statistics

def compute_interarrival(df):
    df = df.dropna(subset=["ts","src","dst"]).copy()
    if df.empty:
        return {k: pd.DataFrame() for k in [
            "pair_all","pair_normal_strict","pair_m_strict",
            "app_all","app_normal_strict","app_m_strict"
        ]}

    df["pair"] = df.apply(lambda r: tuple(sorted([str(r["src"]), str(r["dst"])])), axis=1)
    df = df.sort_values(["pair","app","ts"])
    groups = df.groupby(["pair","app"], sort=False)
    rows_all, rows_norm, rows_mal = [], [], []

    for (pair, app), g in groups:
        ts = g["ts"].to_numpy(float)
        is_m = g["is_mal"].to_numpy()
        is_n = ~is_m
        if len(ts) < 2: 
            continue

        # ALL
        d = np.diff(ts)
        rows_all.append((pair[0],pair[1],app,"ALL",len(d),float(np.mean(d)),
                         float(np.std(d,ddof=1)) if len(d)>1 else 0.0,float(np.median(d))))

        # NORMAL strict
        n_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_n[i] and is_n[i+1]]
        if n_d:
            n_d = np.array(n_d,float)
            rows_norm.append((pair[0],pair[1],app,"NORMAL_strict",len(n_d),
                              float(np.mean(n_d)),float(np.std(n_d,ddof=1)) if len(n_d)>1 else 0.0,
                              float(np.median(n_d))))

        # MALICIOUS strict
        m_d = [ts[i+1]-ts[i] for i in range(len(ts)-1) if is_m[i] and is_m[i+1]]
        if m_d:
            m_d = np.array(m_d,float)
            rows_mal.append((pair[0],pair[1],app,"MALICIOUS_strict",len(m_d),
                             float(np.mean(m_d)),float(np.std(m_d,ddof=1)) if len(m_d)>1 else 0.0,
                             float(np.median(m_d))))

    cols = ["src","dst","app","subset","count","mean","std","median"]
    df_all  = pd.DataFrame(rows_all,  columns=cols)
    df_norm = pd.DataFrame(rows_norm, columns=cols)
    df_mal  = pd.DataFrame(rows_mal,  columns=cols)

    def agg(df, name):
        if df.empty: 
            return pd.DataFrame(columns=["app","subset","count","mean","std","median"])
        g = df.groupby("app",as_index=False)
        rows=[]
        for app,grp in g:
            c=grp["count"].sum()
            m=(grp["count"]*grp["mean"]).sum()/c
            s=np.sqrt(((grp["count"]*(grp["std"]**2)).sum())/max(c-1,1)) if c>1 else 0.0
            med=(grp["count"]*grp["median"]).sum()/c
            rows.append((app,name,c,m,s,med))
        return pd.DataFrame(rows,columns=["app","subset","count","mean","std","median"])

    return {
        "pair_all":df_all,
        "pair_normal_strict":df_norm,
        "pair_m_strict":df_mal,
        "app_all":agg(df_all,"ALL"),
        "app_normal_strict":agg(df_norm,"NORMAL_strict"),
        "app_m_strict":agg(df_mal,"MALICIOUS_strict")
    }


# Save structured CSV

def save_structured(length_all,length_norm,length_mal,inter,outdir,pcap):
    os.makedirs(outdir,exist_ok=True)
    base=os.path.splitext(os.path.basename(pcap))[0]
    path=os.path.join(outdir,f"summary_{base}.csv")
    rows=[]
    def add(df,sec):
        if df.empty: 
            return
        for _,r in df.iterrows():
            rows.append({
                "section":sec,"app_protocol":r.get("app",""),"src_ip":r.get("src",""),
                "dst_ip":r.get("dst",""),"subset":r.get("subset",""),
                "count":r.get("count",""),"mean":r.get("mean",""),
                "std":r.get("std",""),"median":r.get("median","")
            })
    add(length_all,"length_app_overall")
    add(length_norm,"length_app_normal")
    add(length_mal,"length_app_malicious")
    add(inter["pair_all"],"interarrival_pair_all")
    add(inter["pair_normal_strict"],"interarrival_pair_normal_strict")
    add(inter["pair_m_strict"],"interarrival_pair_malicious_strict")
    add(inter["app_all"],"interarrival_app_all")
    add(inter["app_normal_strict"],"interarrival_app_normal_strict")
    add(inter["app_m_strict"],"interarrival_app_malicious_strict")
    pd.DataFrame(rows).to_csv(path,index=False)
    return path


# Pretty CSV & print summary

def _block_lengths(df,title):
    lines=[f"Packet length (bytes) — only packets WITH application data ({title}):"]
    if df.empty: 
        lines.append("  (none)")
    else:
        for _,r in df.sort_values(["app"]).iterrows():
            lines.append(f"  {r['app']}: count={int(r['count'])}, mean={r['mean']:.3f} B, std={0 if pd.isna(r['std']) else r['std']:.3f} B, median={r['median']:.3f} B")
    lines.append("")
    return lines

def _block_pairs(df,title):
    lines=[f"Inter-arrival time (seconds) — same unordered host pair AND same app — {title}:"]
    if df.empty: 
        lines.append("  (none)")
    else:
        for _,r in df.sort_values(["app","src","dst"]).iterrows():
            lines.append(f"  {r['app']} {r['src']} ↔ {r['dst']}: deltas={int(r['count'])}, mean={r['mean']:.6f}s, std={0 if pd.isna(r['std']) else r['std']:.6f}s, median={r['median']:.6f}s")
    lines.append("")
    return lines

def save_pretty(length_all,length_norm,length_mal,inter,outdir,pcap):
    base=os.path.splitext(os.path.basename(pcap))[0]
    path=os.path.join(outdir,f"summary_pretty_{base}.csv")
    lines=["=== Task 1(b) Summary ===",""]
    lines+=_block_lengths(length_all,"ALL")
    lines+=_block_lengths(length_norm,"NORMAL")
    lines+=_block_lengths(length_mal,"MALICIOUS")
    lines+=_block_pairs(inter["pair_all"],"ALL packets")
    lines+=_block_pairs(inter["pair_normal_strict"],"NORMAL_strict (between two consecutive normal packets)")
    lines+=_block_pairs(inter["pair_m_strict"],"MALICIOUS_strict (between two consecutive malicious packets)")
    pd.DataFrame({"text":lines}).to_csv(path,index=False)
    return path

def print_summary(length_all,length_norm,length_mal,inter):
    print("\n=== Task 1(b) Summary ===")
    for block in _block_lengths(length_all,"ALL"): print(block)
    for block in _block_lengths(length_norm,"NORMAL"): print(block)
    for block in _block_lengths(length_mal,"MALICIOUS"): print(block)
    for block in _block_pairs(inter["pair_all"],"ALL packets"): print(block)
    for block in _block_pairs(inter["pair_normal_strict"],"NORMAL_strict (between two consecutive normal packets)"): print(block)
    for block in _block_pairs(inter["pair_m_strict"],"MALICIOUS_strict (between two consecutive malicious packets)"): print(block)



# Main

def main():
    ap = argparse.ArgumentParser(
        description="Task 1(b): Length & Inter-arrival stats (split NORMAL vs MALICIOUS)"
    )

    # Argument order
    ap.add_argument("--pcap", required=True, help="Path to the PCAP file to analyze")
    ap.add_argument(
        "--A",
        type=int,
        choices=[0, 1],
        required=True,
        help="Attack flag: 1 = whole PCAP is attacked, 0 = whole PCAP is normal",
    )
    ap.add_argument(
        "--outdir",
        default=".",
        help="Output directory for generated CSVs (default: current folder)",
    )

    # Optional
    ap.add_argument("--labels", help="Optional labels CSV (frame_number;label)")
    ap.add_argument("--verbose", action="store_true", help="Enable detailed output")
    args = ap.parse_args()

    # Validation
    if not os.path.exists(args.pcap):
        raise SystemExit(f"PCAP not found: {args.pcap}")
    if args.labels and not os.path.exists(args.labels):
        raise SystemExit(f"Labels not found: {args.labels}")

    all_malicious = (args.A == 1)
    if args.verbose:
        print(f"[info] --A = {args.A} -> all_malicious={all_malicious}")
        if args.labels:
            print(f"[info] labels file provided: {args.labels}")

    mal = load_labels(args.labels, verbose=args.verbose)
    df = collect_packets(args.pcap, mal, all_malicious=all_malicious, verbose=args.verbose)
    df_app = df[df["app"].apply(is_application_layer)].copy()

    length_all, length_norm, length_mal = compute_length_stats(df_app)
    inter = compute_interarrival(df_app)

    print_summary(length_all, length_norm, length_mal, inter)
    path1 = save_structured(length_all, length_norm, length_mal, inter, args.outdir, args.pcap)
    path2 = save_pretty(length_all, length_norm, length_mal, inter, args.outdir, args.pcap)
    print(f"\nSaved CSV (structured) → {path1}")
    print(f"Saved CSV (pretty)     → {path2}")
    print("Done.")


if __name__ == "__main__":
    main()

