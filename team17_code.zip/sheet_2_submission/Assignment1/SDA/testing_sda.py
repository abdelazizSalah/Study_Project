from stackedDenoisingAutoEncoder import SDA
from keras.utils import to_categorical
from keras.datasets import mnist

from matplotlib import pyplot as plt

n_classes = 10

# input image dimensions
img_rows, img_cols = 28, 28

# the data, shuffled and split between train and test sets
(X_train, y_train), (X_test, y_test) = mnist.load_data()


X_train = X_train.reshape(X_train.shape[0], 784)
X_test = X_test.reshape(X_test.shape[0], 784)
X_train = X_train.astype('float32')
X_test = X_test.astype('float32')
X_train /= 255
X_test /= 255
print(X_train.shape[0], 'train samples')
print(X_test.shape[0], 'test samples')

# convert class vectors to binary class matrices
Y_train = to_categorical(y_train, n_classes)
Y_test = to_categorical(y_test, n_classes)

X_train_50 = X_train[0:50]

n_in = n_out = X_train.shape[1]
n_hid = 576

cur_sdae = SDA(2, [20], [0.1], 'Dense', 'relu', ['relu'], ['relu'], True, 
               'mse', 256, 2, 'adam', 0.1 )

#train a stacked denoising autoencoder and get the trained model, dense representations of the final hidden layer, and reconstruction error
model, dense_train, dense_val, dense_test, recon_mse = cur_sdae.getSDAModel(X_train, X_test, X_test, outputDirectory = 'models_and_data/')
